import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Plus, Video, MapPin, Clock, Loader2, Calendar as CalendarIcon, RefreshCw } from "lucide-react";
import { SiGoogle } from "react-icons/si";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface CalendarEvent {
  id: string;
  title: string;
  description?: string | null;
  eventType: string;
  startTime: string;
  endTime?: string | null;
  location?: string | null;
  isVirtual?: boolean;
  isGoogleEvent?: boolean;
}

interface GoogleCalendarEvent {
  id: string;
  title: string;
  description?: string;
  startTime: string;
  endTime?: string;
  location?: string;
  isGoogleEvent: boolean;
}

const eventTypeLabels: Record<string, string> = {
  meeting: "Встреча",
  virtual: "Онлайн",
  reminder: "Напоминание",
  task: "Задача",
};

export function CalendarPage() {
  const { toast } = useToast();
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState("");
  const [eventType, setEventType] = useState("meeting");
  const [datetime, setDatetime] = useState("");
  const [location, setLocation] = useState("");
  const [addToGoogle, setAddToGoogle] = useState(false);
  const [showGoogleEvents, setShowGoogleEvents] = useState(false);

  const { data, isLoading } = useQuery<{ success: boolean; events: CalendarEvent[] }>({
    queryKey: ["/api/events"],
  });

  const { data: googleStatusData } = useQuery<{ success: boolean; connected: boolean }>({
    queryKey: ["/api/google-calendar/status"],
  });

  const { data: googleEventsData, isLoading: isLoadingGoogle, refetch: refetchGoogleEvents } = useQuery<{ success: boolean; events: GoogleCalendarEvent[] }>({
    queryKey: ["/api/google-calendar/events"],
    enabled: showGoogleEvents && googleStatusData?.connected,
  });

  const isGoogleConnected = googleStatusData?.connected || false;

  const createMutation = useMutation({
    mutationFn: async (event: { title: string; eventType: string; startTime: string; location: string; addToGoogle: boolean }) => {
      return apiRequest("POST", "/api/events", {
        ...event,
        isVirtual: event.eventType === "virtual",
      });
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      setShowForm(false);
      setTitle("");
      setDatetime("");
      setLocation("");
      setAddToGoogle(false);
      
      if (data.googleEventId) {
        toast({
          title: "Событие создано",
          description: "Событие также добавлено в Google Calendar, сэр.",
        });
      }
    },
  });

  const syncMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/google-calendar/sync", {});
    },
    onSuccess: (data: any) => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      toast({
        title: "Синхронизация завершена",
        description: data.message || `Синхронизировано ${data.synced} событий, сэр.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Ошибка синхронизации",
        description: error.message || "Не удалось синхронизировать с Google Calendar",
        variant: "destructive",
      });
    },
  });

  const events = data?.events || [];
  const googleEvents = googleEventsData?.events || [];

  const handleAddEvent = () => {
    if (!title || !datetime) return;
    createMutation.mutate({ title, eventType, startTime: datetime, location, addToGoogle });
  };

  const formatEventDate = (dateStr: string) => {
    const date = new Date(dateStr);
    const day = date.getDate();
    const months = ["янв", "фев", "мар", "апр", "май", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"];
    return { day, month: months[date.getMonth()] };
  };

  const formatEventTime = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-primary" data-testid="text-calendar-title">
          Календарь
        </h1>
        <p className="text-muted-foreground text-sm">Встречи и события</p>
      </div>

      <Card className="card-cyber border-primary/30 bg-primary/5">
        <CardContent className="py-3 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
            <Calendar className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="text-primary font-medium text-sm">Локальный календарь</p>
            <p className="text-muted-foreground text-xs">События сохраняются на сервере</p>
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-col gap-3">
        <Button 
          className="w-full bg-gradient-primary gap-2"
          onClick={() => setShowForm(!showForm)}
          data-testid="button-add-event"
        >
          <Plus className="w-4 h-4" />
          Добавить событие
        </Button>

        {isGoogleConnected && (
          <div className="flex gap-2">
            <Button
              variant="outline"
              className="flex-1 gap-2"
              onClick={() => syncMutation.mutate()}
              disabled={syncMutation.isPending}
              data-testid="button-sync-google"
            >
              {syncMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4" />
              )}
              Синхронизировать с Google
            </Button>
            <Button
              variant={showGoogleEvents ? "default" : "outline"}
              size="icon"
              onClick={() => {
                setShowGoogleEvents(!showGoogleEvents);
                if (!showGoogleEvents) {
                  refetchGoogleEvents();
                }
              }}
              data-testid="button-toggle-google-events"
            >
              <SiGoogle className="w-4 h-4" />
            </Button>
          </div>
        )}

        {!isGoogleConnected && (
          <Card className="card-cyber">
            <CardContent className="py-4">
              <div className="flex items-center gap-3 text-muted-foreground text-sm">
                <SiGoogle className="w-4 h-4" />
                <span>Google Calendar не подключён. Подключите интеграцию в настройках Replit.</span>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {showForm && (
        <Card className="card-cyber">
          <CardHeader>
            <CardTitle className="text-sm">Новое событие</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Название</Label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Название события"
                className="bg-muted border-primary/20"
                data-testid="input-event-title"
              />
            </div>

            <div className="space-y-2">
              <Label>Дата и время</Label>
              <Input
                type="datetime-local"
                value={datetime}
                onChange={(e) => setDatetime(e.target.value)}
                className="bg-muted border-primary/20"
                data-testid="input-event-datetime"
              />
            </div>

            <div className="space-y-2">
              <Label>Тип</Label>
              <Select value={eventType} onValueChange={setEventType}>
                <SelectTrigger className="bg-muted border-primary/20" data-testid="select-event-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="meeting">Встреча</SelectItem>
                  <SelectItem value="virtual">Виртуальная встреча</SelectItem>
                  <SelectItem value="reminder">Напоминание</SelectItem>
                  <SelectItem value="task">Задача</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Место</Label>
              <Input
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Опционально"
                className="bg-muted border-primary/20"
                data-testid="input-event-location"
              />
            </div>

            {isGoogleConnected && (
              <div className="flex items-center justify-between">
                <Label className="flex items-center gap-2">
                  <SiGoogle className="w-4 h-4" />
                  Добавить в Google Calendar
                </Label>
                <Switch
                  checked={addToGoogle}
                  onCheckedChange={setAddToGoogle}
                  data-testid="switch-add-to-google"
                />
              </div>
            )}

            <Button 
              className="w-full bg-gradient-primary"
              onClick={handleAddEvent}
              disabled={createMutation.isPending}
              data-testid="button-save-event"
            >
              {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Создать событие"}
            </Button>
          </CardContent>
        </Card>
      )}

      {showGoogleEvents && isGoogleConnected && (
        <div className="space-y-3">
          <h3 className="text-sm text-muted-foreground flex items-center gap-2">
            <SiGoogle className="w-4 h-4" />
            События из Google Calendar
          </h3>
          {isLoadingGoogle ? (
            <div className="flex items-center justify-center h-32">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
            </div>
          ) : googleEvents.length === 0 ? (
            <Card className="card-cyber">
              <CardContent className="py-6 text-center">
                <div className="text-muted-foreground text-sm">Нет событий в Google Calendar</div>
              </CardContent>
            </Card>
          ) : (
            googleEvents.map((event) => {
              const { day, month } = formatEventDate(event.startTime);
              
              return (
                <Card key={event.id} className="card-cyber border-blue-500/30" data-testid={`card-google-event-${event.id}`}>
                  <CardContent className="py-4">
                    <div className="flex gap-4">
                      <div className="text-center min-w-14">
                        <div className="text-2xl font-bold text-blue-400">{day}</div>
                        <div className="text-xs text-muted-foreground uppercase">{month}</div>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium">{event.title}</h4>
                          <SiGoogle className="w-3 h-3 text-blue-400" />
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                          <Clock className="w-3 h-3" />
                          {formatEventTime(event.startTime)}
                        </div>
                        {event.location && (
                          <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                            <MapPin className="w-3 h-3" />
                            {event.location}
                          </div>
                        )}
                        <Badge variant="outline" className="mt-2 text-xs border-blue-500/50 text-blue-400">
                          Google Calendar
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </div>
      )}

      <div className="space-y-3">
        <h3 className="text-sm text-muted-foreground">Ближайшие события</h3>
        {events.length === 0 ? (
          <Card className="card-cyber">
            <CardContent className="py-8 text-center">
              <CalendarIcon className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
              <div className="text-muted-foreground">Нет запланированных событий</div>
            </CardContent>
          </Card>
        ) : (
          events.map((event) => {
            const { day, month } = formatEventDate(event.startTime);
            const isFromGoogle = event.title.startsWith("[Google]");
            
            return (
              <Card key={event.id} className={cn("card-cyber", isFromGoogle && "border-blue-500/20")} data-testid={`card-event-${event.id}`}>
                <CardContent className="py-4">
                  <div className="flex gap-4">
                    <div className="text-center min-w-14">
                      <div className={cn("text-2xl font-bold", isFromGoogle ? "text-blue-400" : "text-primary")}>{day}</div>
                      <div className="text-xs text-muted-foreground uppercase">{month}</div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="font-medium">{isFromGoogle ? event.title.replace("[Google] ", "") : event.title}</h4>
                        {isFromGoogle && <SiGoogle className="w-3 h-3 text-blue-400" />}
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                        <Clock className="w-3 h-3" />
                        {formatEventTime(event.startTime)}
                      </div>
                      {event.location && (
                        <div className="flex items-center gap-2 mt-1 text-xs text-muted-foreground">
                          {event.isVirtual || event.eventType === "virtual" ? (
                            <Video className="w-3 h-3" />
                          ) : (
                            <MapPin className="w-3 h-3" />
                          )}
                          {event.location}
                        </div>
                      )}
                      <Badge 
                        variant="outline" 
                        className={cn(
                          "mt-2 text-xs",
                          isFromGoogle && "border-blue-500/50 text-blue-400",
                          !isFromGoogle && event.eventType === "virtual" && "border-secondary text-secondary",
                          !isFromGoogle && event.eventType === "meeting" && "border-primary text-primary",
                          !isFromGoogle && event.eventType === "reminder" && "border-yellow-500 text-yellow-500"
                        )}
                      >
                        {isFromGoogle ? "Google Calendar" : (eventTypeLabels[event.eventType] || event.eventType)}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}

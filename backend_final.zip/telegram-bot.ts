          this.lastUpdateId = update.update_id;
          await this.handleMessage(update.message);
        }
      } catch (error) {
        console.error("[Telegram] Polling error:", error);
        await new Promise((resolve) => setTimeout(resolve, 5000));
      }

      await new Promise((resolve) => setTimeout(resolve, this.pollInterval));
    }
  }

  async start(): Promise<void> {
    if (this.isRunning) {
      console.log("[Telegram] Bot is already running");
      return;
    }

    this.isRunning = true;
    console.log("[Telegram] Bot started, polling for updates...");

    try {
      const me = await this.apiCall("getMe") as { ok: boolean; result?: { username: string } };
      if (me.ok && me.result) {
        console.log(`[Telegram] Bot connected as @${me.result.username}`);
      }
    } catch (error) {
      console.error("[Telegram] Failed to get bot info:", error);
    }

    this.pollLoop().catch((error) => {
      console.error("[Telegram] Poll loop crashed:", error);
      this.isRunning = false;
    });
  }

  stop(): void {
    this.isRunning = false;
    console.log("[Telegram] Bot stopped");
  }
}

let botInstance: TelegramBot | null = null;

export function startTelegramBot(): void {
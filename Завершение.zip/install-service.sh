#!/bin/bash
# Скрипт установки JarVoice как системного сервиса
# Запускать с правами sudo: sudo ./install-service.sh

set -e

echo "🤖 Установка JarVoice как системного сервиса..."

# Проверка прав
if [ "$EUID" -ne 0 ]; then
  echo "❌ Пожалуйста, запустите скрипт с правами sudo"
  exit 1
fi

# Путь к проекту
PROJECT_DIR="/home/ubuntu/Jarvis-project/Jarvis-1"
SERVICE_FILE="$PROJECT_DIR/jarvoice.service"

# Проверка существования файлов
if [ ! -f "$SERVICE_FILE" ]; then
  echo "❌ Файл сервиса не найден: $SERVICE_FILE"
  exit 1
fi

if [ ! -f "$PROJECT_DIR/dist/index.cjs" ]; then
  echo "❌ Собранный проект не найден. Запустите npm run build"
  exit 1
fi

# Остановка существующего сервиса если запущен
if systemctl is-active --quiet jarvoice; then
  echo "⏹️ Остановка существующего сервиса..."
  systemctl stop jarvoice
fi

# Копирование файла сервиса
echo "📋 Копирование файла сервиса..."
cp "$SERVICE_FILE" /etc/systemd/system/jarvoice.service

# Перезагрузка systemd
echo "🔄 Перезагрузка systemd..."
systemctl daemon-reload

# Включение автозапуска
echo "✅ Включение автозапуска..."
systemctl enable jarvoice

# Запуск сервиса
echo "🚀 Запуск сервиса..."
systemctl start jarvoice

# Проверка статуса
echo ""
echo "📊 Статус сервиса:"
systemctl status jarvoice --no-pager

echo ""
echo "✅ JarVoice успешно установлен как системный сервис!"
echo ""
echo "📝 Полезные команды:"
echo "   sudo systemctl status jarvoice  - проверить статус"
echo "   sudo systemctl stop jarvoice    - остановить"
echo "   sudo systemctl start jarvoice   - запустить"
echo "   sudo systemctl restart jarvoice - перезапустить"
echo "   sudo journalctl -u jarvoice -f  - просмотр логов в реальном времени"
echo ""
echo "⏰ Сервис будет автоматически перезапускаться каждые 24 часа"
echo "   с сохранением всех сессий пользователей."

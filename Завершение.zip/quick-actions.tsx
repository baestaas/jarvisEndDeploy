import { Clock, CalendarDays, Languages, Cloud, Bell, Heart, Newspaper } from "lucide-react";
import { cn } from "@/lib/utils";

interface QuickAction {
  id: string;
  label: string;
  icon: typeof Clock;
  command?: string;
  section?: string;
}

const quickActions: QuickAction[] = [
  { id: "time", label: "Время", icon: Clock, command: "который час" },
  { id: "date", label: "Дата", icon: CalendarDays, command: "какая сегодня дата" },
  { id: "weather", label: "Погода", icon: Cloud, section: "weather" },
  { id: "translate", label: "Перевод", icon: Languages, section: "translate" },
  { id: "reminders", label: "Напоминания", icon: Bell, section: "reminders" },
  { id: "mood", label: "Настроение", icon: Heart, section: "mood" },
  { id: "news", label: "Новости", icon: Newspaper, section: "news" },
  { id: "calendar", label: "Календарь", icon: CalendarDays, section: "calendar" },
];

interface QuickActionsProps {
  onCommand: (command: string) => void;
  onNavigate: (section: string) => void;
}

export function QuickActions({ onCommand, onNavigate }: QuickActionsProps) {
  return (
    <div className="grid grid-cols-4 gap-3" data-testid="quick-actions">
      {quickActions.map((action) => {
        const Icon = action.icon;
        
        return (
          <button
            key={action.id}
            onClick={() => {
              if (action.command) {
                onCommand(action.command);
              } else if (action.section) {
                onNavigate(action.section);
              }
            }}
            className={cn(
              "card-cyber p-4 flex flex-col items-center gap-2",
              "transition-all duration-200",
              "hover:border-primary/50 hover:-translate-y-0.5"
            )}
            data-testid={`quick-${action.id}`}
          >
            <Icon className="w-5 h-5 text-primary" />
            <span className="text-xs text-muted-foreground">{action.label}</span>
          </button>
        );
      })}
    </div>
  );
}

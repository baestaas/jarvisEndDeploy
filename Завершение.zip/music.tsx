import { 
  Music, Play, Pause, SkipBack, SkipForward, 
  Volume2, VolumeX, Shuffle, Repeat, Repeat1,
  ListMusic, Disc3
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { cn } from "@/lib/utils";

interface Track {
  id: string;
  title: string;
  artist: string;
  duration: number;
  genre: string;
}

interface Playlist {
  id: string;
  name: string;
  icon: string;
  tracks: Track[];
}

const mockPlaylists: Playlist[] = [
  {
    id: "calm",
    name: "Спокойное",
    icon: "calm",
    tracks: [
      { id: "c1", title: "Тихий океан", artist: "Ambient Waves", duration: 245, genre: "calm" },
      { id: "c2", title: "Ночное небо", artist: "Dream Sounds", duration: 312, genre: "calm" },
      { id: "c3", title: "Утренний туман", artist: "Nature Vibes", duration: 198, genre: "calm" },
      { id: "c4", title: "Лесная тишина", artist: "Relax Master", duration: 267, genre: "calm" },
    ],
  },
  {
    id: "work",
    name: "Рабочее",
    icon: "work",
    tracks: [
      { id: "w1", title: "Фокус", artist: "Productivity Beats", duration: 180, genre: "work" },
      { id: "w2", title: "Deep Focus", artist: "Brain Boost", duration: 240, genre: "work" },
      { id: "w3", title: "Концентрация", artist: "Mind Flow", duration: 210, genre: "work" },
      { id: "w4", title: "Поток мыслей", artist: "Work Mode", duration: 195, genre: "work" },
    ],
  },
  {
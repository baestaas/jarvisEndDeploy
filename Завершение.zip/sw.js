const STATIC_CACHE = 'jarvoice-static-v2';
const DATA_CACHE = 'jarvoice-data-v2';

const STATIC_URLS = [
  '/',
  '/manifest.json',
  '/icon-192.png',
  '/icon-512.png'
];

const API_CACHE_URLS = [
  '/api/events',
  '/api/finance',
  '/api/reminders',
  '/api/user'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(STATIC_CACHE)
      .then((cache) => cache.addAll(STATIC_URLS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.filter((name) => 
          name !== STATIC_CACHE && 
          name !== DATA_CACHE && 
          name !== CACHE_NAME
        ).map((name) => caches.delete(name))
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;
  
  const url = new URL(event.request.url);
  
  if (url.pathname.startsWith('/api/')) {
    const shouldCache = API_CACHE_URLS.some(path => url.pathname.startsWith(path));
    
    if (shouldCache) {
      event.respondWith(
        fetch(event.request)
          .then((response) => {
            if (response.ok) {
              const responseClone = response.clone();
              caches.open(DATA_CACHE).then((cache) => {
                cache.put(event.request, responseClone);
              });
            }
            return response;
          })
          .catch(() => {
            return caches.match(event.request).then((cached) => {
              if (cached) {
                return cached;
              }
              return new Response(JSON.stringify({ 
                success: false, 
                error: 'Offline', 
                offline: true 
              }), {
                headers: { 'Content-Type': 'application/json' }
              });
            });
          })
      );
      return;
    }
    
    event.respondWith(
      fetch(event.request)
        .catch(() => new Response(JSON.stringify({ 
          success: false, 
          error: 'Offline',
          offline: true 
        }), {
          headers: { 'Content-Type': 'application/json' }
        }))
    );
    return;
  }
  
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        if (response) return response;
        
        return fetch(event.request).then((response) => {
          if (!response || response.status !== 200) return response;
          
          const responseToCache = response.clone();
          caches.open(STATIC_CACHE).then((cache) => {
            cache.put(event.request, responseToCache);
          });
          
          return response;
        }).catch(() => {
          if (event.request.destination === 'document') {
            return caches.match('/');
          }
          return new Response('Offline', { status: 503 });
        });
      })
  );
});

self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'OFFLINE_COMMAND') {
    const command = event.data.command.toLowerCase();
    let response = null;
    
    const now = new Date();
    const timeStr = now.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
    const dateStr = now.toLocaleDateString('ru-RU', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
    
    if (command.includes('время') || command.includes('час')) {
      response = `Сейчас ${timeStr}, сэр.`;
    } else if (command.includes('дата') || command.includes('число') || command.includes('день')) {
      response = `Сегодня ${dateStr}, сэр.`;
    } else if (command.includes('привет') || command.includes('здравствуй')) {
      response = `Здравствуйте, сэр. К сожалению, я работаю в автономном режиме и мои возможности ограничены.`;
    } else if (command.includes('помощь') || command.includes('команды')) {
      response = `В автономном режиме доступны команды: время, дата, день недели. Для полного функционала необходимо подключение к сети, сэр.`;
    } else if (command.includes('спасибо')) {
      response = `Всегда к вашим услугам, сэр.`;
    }
    
    event.ports[0].postMessage({ 
      success: !!response, 
      response: response,
      offline: true 
    });
  }
  
  if (event.data && event.data.type === 'CLEAR_CACHE') {
    event.waitUntil(
      caches.keys().then((names) => Promise.all(names.map(n => caches.delete(n))))
    );
  }
});

self.addEventListener('push', (event) => {
  let data = {
    title: 'JarVoice',
    body: 'Новое уведомление, сэр',
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    tag: 'jarvoice-notification',
    data: {}
  };

  if (event.data) {
    try {
      const payload = event.data.json();
      data = { ...data, ...payload };
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const options = {
    body: data.body,
    icon: data.icon || '/icon-192.png',
    badge: data.badge || '/icon-192.png',
    tag: data.tag || 'jarvoice-notification',
    vibrate: [200, 100, 200],
    data: data.data || {},
    actions: [
      { action: 'open', title: 'Открыть' },
      { action: 'dismiss', title: 'Закрыть' }
    ],
    requireInteraction: true
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'dismiss') {
    return;
  }

  const urlToOpen = '/';
  
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        for (const client of clientList) {
          if (client.url.includes(self.location.origin) && 'focus' in client) {
            return client.focus();
          }
        }
        if (clients.openWindow) {
          return clients.openWindow(urlToOpen);
        }
      })
  );
});

self.addEventListener('notificationclose', (event) => {
  console.log('[SW] Notification closed:', event.notification.tag);
});

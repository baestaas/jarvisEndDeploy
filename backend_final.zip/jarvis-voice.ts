/**
 * Модуль синтеза голоса Джарвиса
 * Использует Yandex SpeechKit и Google Cloud TTS для создания аутентичного голоса
 * с характеристиками Джарвиса из русской озвучки фильмов про Железного Человека
 */

import OpenAI from "openai";
import axios from "axios";

// Создаём OpenAI клиент только если есть API ключ
let openai: OpenAI | null = null;

const apiKey = process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
if (apiKey) {
  try {
    openai = new OpenAI({
      apiKey: apiKey,
      baseURL: 'https://api.openai.com/v1', // Прямое подключение для TTS
    });
  } catch (e) {
    console.warn('[Jarvis Voice] OpenAI клиент не инициализирован:', e);
  }
} else {
  console.warn('[Jarvis Voice] OPENAI_API_KEY не установлен, TTS будет использовать браузерный Web Speech API');
}

export interface JarvisVoiceConfig {
  provider: "openai" | "yandex" | "google";
  language: "ru" | "en";
  speed: number; // 0.5 - 2.0
  pitch: number; // 0.5 - 2.0
  volume: number; // 0.0 - 1.0
}

const DEFAULT_JARVIS_CONFIG: JarvisVoiceConfig = {
  provider: "openai",
  language: "ru",
  speed: 0.85, // Немного медленнее для аристократичного звучания
  pitch: 0.9, // Немного ниже для более глубокого голоса
  volume: 1.0,
};

/**
 * Синтез голоса Джарвиса с использованием OpenAI TTS
 * Выбирает голос "echo" как наиболее подходящий для Джарвиса
 */
export async function synthesizeJarvisVoiceOpenAI(
  text: string,
  config: Partial<JarvisVoiceConfig> = {}
): Promise<Buffer> {
  const finalConfig = { ...DEFAULT_JARVIS_CONFIG, ...config };

  if (!openai) {
    throw new Error('Ошибка: OpenAI клиент не инициализирован. Используйте браузерный Web Speech API.');
  }

  try {
    const response = await openai.audio.speech.create({
      model: "tts-1",
      voice: "echo", // "echo" имеет более глубокий, аристократичный тон
      input: text,
      response_format: "mp3",
      speed: finalConfig.speed,
    });

    const arrayBuffer = await response.arrayBuffer();
    return Buffer.from(arrayBuffer);
  } catch (error) {
    console.error("OpenAI TTS error:", error);
    throw new Error("Не удалось синтезировать голос Джарвиса (OpenAI)");
  }
}

/**
 * Синтез голоса Джарвиса с использованием Yandex SpeechKit
 * Yandex имеет лучшую поддержку русского языка и более качественные голоса
 */
export async function synthesizeJarvisVoiceYandex(
  text: string,
  config: Partial<JarvisVoiceConfig> = {}
): Promise<Buffer> {
  const finalConfig = { ...DEFAULT_JARVIS_CONFIG, ...config };
  const yandexApiKey = process.env.YANDEX_SPEECHKIT_API_KEY;
  const yandexFolderId = process.env.YANDEX_FOLDER_ID;

  if (!yandexApiKey || !yandexFolderId) {
    console.warn("Yandex SpeechKit credentials not configured, falling back to OpenAI");
    return synthesizeJarvisVoiceOpenAI(text, config);
  }

  try {
    const response = await axios.post(
      "https://tts.api.cloud.yandex.net/speech/v1/tts:synthesize",
      {
        text,
        ssmlText: `<speak>${text}</speak>`,
        lang: "ru-RU",
        voice: "filipp", // Филипп - глубокий мужской голос, подходит для Джарвиса
        emotion: "neutral", // Нейтральная эмоция для профессионального звучания
        speed: finalConfig.speed,
        format: "mp3",
      },
      {
        headers: {
          Authorization: `Api-Key ${yandexApiKey}`,
          "x-folder-id": yandexFolderId,
        },
        responseType: "arraybuffer",
      }
    );

    return Buffer.from(response.data);
  } catch (error) {
    console.error("Yandex SpeechKit error:", error);
    console.warn("Falling back to OpenAI TTS");
    return synthesizeJarvisVoiceOpenAI(text, config);
  }
}

/**
 * Синтез голоса Джарвиса с использованием Google Cloud TTS
 * Google Cloud имеет высокое качество и хорошую поддержку русского языка
 */
export async function synthesizeJarvisVoiceGoogle(
  text: string,
  config: Partial<JarvisVoiceConfig> = {}
): Promise<Buffer> {
  const finalConfig = { ...DEFAULT_JARVIS_CONFIG, ...config };
  const googleApiKey = process.env.GOOGLE_CLOUD_TTS_API_KEY;

  if (!googleApiKey) {
    console.warn("Google Cloud TTS credentials not configured, falling back to OpenAI");
    return synthesizeJarvisVoiceOpenAI(text, config);
  }

  try {
    const response = await axios.post(
      `https://texttospeech.googleapis.com/v1/text:synthesize?key=${googleApiKey}`,
      {
        input: { text },
        voice: {
          languageCode: "ru-RU",
          name: "ru-RU-Neural2-D", // Глубокий мужской голос
          ssmlGender: "MALE",
        },
        audioConfig: {
          audioEncoding: "MP3",
          pitch: finalConfig.pitch - 1, // Google использует диапазон -20 до 20
          speakingRate: finalConfig.speed,
        },
      }
    );

    const audioContent = response.data.audioContent;
    return Buffer.from(audioContent, "base64");
  } catch (error) {
    console.error("Google Cloud TTS error:", error);
    console.warn("Falling back to OpenAI TTS");
    return synthesizeJarvisVoiceOpenAI(text, config);
  }
}

/**
 * Основная функция синтеза голоса Джарвиса
 * Выбирает оптимальный провайдер и синтезирует речь
 */
export async function synthesizeJarvisVoice(
  text: string,
  config: Partial<JarvisVoiceConfig> = {}
): Promise<Buffer> {
  const finalConfig = { ...DEFAULT_JARVIS_CONFIG, ...config };

  console.log(`[Jarvis Voice] Синтезирование: "${text.substring(0, 50)}..."`);
  console.log(`[Jarvis Voice] Провайдер: ${finalConfig.provider}`);

  try {
    switch (finalConfig.provider) {
      case "yandex":
        return await synthesizeJarvisVoiceYandex(text, finalConfig);
      case "google":
        return await synthesizeJarvisVoiceGoogle(text, finalConfig);
      case "openai":
      default:
        return await synthesizeJarvisVoiceOpenAI(text, finalConfig);
    }
  } catch (error) {
    console.error("Error synthesizing Jarvis voice:", error);
    // Всегда падаем на OpenAI как на последний вариант
    try {
      return await synthesizeJarvisVoiceOpenAI(text, finalConfig);
    } catch (fallbackError) {
      console.error("All TTS providers failed:", fallbackError);
      throw new Error("Не удалось синтезировать голос Джарвиса");
    }
  }
}

/**
 * Добавляет эффекты к голосу для большей аутентичности
 * (например, лёгкий реверберация для эффекта "из динамика")
 */
export async function addJarvisVoiceEffects(audioBuffer: Buffer): Promise<Buffer> {
  // В реальной реализации здесь можно добавить обработку аудио
  // Например, с использованием ffmpeg или Web Audio API на клиенте
  // На данный момент просто возвращаем исходный буфер
  return audioBuffer;
}

/**
 * Получает оптимальный провайдер на основе доступных ключей
 */
export function getOptimalProvider(): JarvisVoiceConfig["provider"] {
  if (process.env.YANDEX_SPEECHKIT_API_KEY && process.env.YANDEX_FOLDER_ID) {
    return "yandex";
  }
  if (process.env.GOOGLE_CLOUD_TTS_API_KEY) {
    return "google";
  }
  return "openai"; // Всегда доступен
}

/**
 * Предварительно синтезирует часто используемые фразы Джарвиса
 * для быстрого ответа без задержки
 */
export const JARVIS_PHRASES = {
  greeting: "Здравствуйте, сэр. Рад вас видеть.",
  listening: "Я слушаю вас, сэр.",
  processing: "Обрабатываю ваш запрос, сэр.",
  success: "Команда выполнена, сэр.",
  error: "Прошу прощения, сэр, но я не смог выполнить эту команду.",
  offline: "К сожалению, я работаю в автономном режиме, сэр.",
  goodbye: "До свидания, сэр. Было приятно с вами работать.",
  thinking: "Позвольте мне подумать, сэр.",
  clarification: "Позвольте уточнить, сэр.",
  confirmation: "Как прикажете, сэр.",
};

/**
 * Кэш для предварительно синтезированных фраз
 */
const phraseCache = new Map<string, Buffer>();

/**
 * Получает или синтезирует фразу Джарвиса
 */
export async function getJarvisPhrase(
  phraseKey: keyof typeof JARVIS_PHRASES,
  config?: Partial<JarvisVoiceConfig>
): Promise<Buffer> {
  const cacheKey = `${phraseKey}_${JSON.stringify(config || {})}`;

  if (phraseCache.has(cacheKey)) {
    return phraseCache.get(cacheKey)!;
  }

  const text = JARVIS_PHRASES[phraseKey];
  const audioBuffer = await synthesizeJarvisVoice(text, config);

  phraseCache.set(cacheKey, audioBuffer);
  return audioBuffer;
}

/**
 * Очищает кэш фраз (например, при смене провайдера)
 */
export function clearPhraseCache(): void {
  phraseCache.clear();
  console.log("[Jarvis Voice] Кэш фраз очищен");
}

// server/db-mock.ts
// Временная заглушка для базы данных Drizzle, чтобы позволить серверу запуститься
// без реального подключения к PostgreSQL.

import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "../shared/schema";

// Создаем фиктивный Pool, который не будет подключаться
const mockPool = {
  connect: () => ({
    query: () => {
      console.warn("MOCK DB: Выполнен фиктивный запрос. Подключение к реальной БД отсутствует.");
      return { rows: [] };
    },
    release: () => {},
  }),
  end: () => {},
} as unknown as Pool;

// Инициализируем Drizzle с фиктивным Pool
export const db = drizzle(mockPool, { schema });

console.warn("ВНИМАНИЕ: Используется фиктивная база данных (db-mock.ts). Функционал, требующий БД, не будет работать.");

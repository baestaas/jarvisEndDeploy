import { User } from "lucide-react";

interface UserHeaderProps {
  username: string;
  role: string;
}

const roleNames: Record<string, string> = {
  owner: "Владелец",
  family: "Семья",
  user: "Пользователь",
};

export function UserHeader({ username, role }: UserHeaderProps) {
  return (
    <div className="flex items-center gap-3 bg-card rounded-full p-2 pr-4" data-testid="user-header">
      <div className="w-10 h-10 rounded-full bg-gradient-primary flex items-center justify-center">
        <User className="w-5 h-5 text-white" />
      </div>
      
      <div className="flex-1">
        <div className="font-medium text-sm" data-testid="text-username">{username}</div>
        <div className="text-xs text-primary uppercase" data-testid="text-role">
          {roleNames[role] || role}
        </div>
      </div>
    </div>
  );
}

import { useState, useRef, useEffect } from "react";
import { Mic, Square, Play, Pause, Trash2, Save, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface VoiceNote {
  id: string;
  title: string;
  audioData: string;
  timestamp: number;
  duration: number;
}

const STORAGE_KEY = "jarvoice_voice_notes";

function loadNotes(): VoiceNote[] {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

function saveNotes(notes: VoiceNote[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}

export function VoiceNotesPage() {
  const [notes, setNotes] = useState<VoiceNote[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [currentTitle, setCurrentTitle] = useState("");
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [isSupported, setIsSupported] = useState(true);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    setNotes(loadNotes());
    
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setIsSupported(false);
    }
  }, []);

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, []);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      chunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          chunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: "audio/webm" });
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = reader.result as string;
          const newNote: VoiceNote = {
            id: Date.now().toString(),
            title: currentTitle || `Заметка ${notes.length + 1}`,
            audioData: base64,
            timestamp: Date.now(),
            duration: recordingTime,
          };
          
          const updatedNotes = [newNote, ...notes];
          setNotes(updatedNotes);
          saveNotes(updatedNotes);
          setCurrentTitle("");
          setRecordingTime(0);
        };
        reader.readAsDataURL(blob);

        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      
      timerRef.current = window.setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error("Ошибка доступа к микрофону:", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  const playNote = (note: VoiceNote) => {
    if (audioRef.current) {
      audioRef.current.pause();
    }

    if (playingId === note.id) {
      setPlayingId(null);
      return;
    }

    const audio = new Audio(note.audioData);
    audioRef.current = audio;
    
    audio.onended = () => {
      setPlayingId(null);
    };
    
    audio.play();
    setPlayingId(note.id);
  };

  const deleteNote = (id: string) => {
    if (playingId === id && audioRef.current) {
      audioRef.current.pause();
      setPlayingId(null);
    }
    
    const updatedNotes = notes.filter(n => n.id !== id);
    setNotes(updatedNotes);
    saveNotes(updatedNotes);
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString("ru-RU", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  if (!isSupported) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="font-display text-2xl text-primary" data-testid="text-voice-notes-title">
            Голосовые заметки
          </h1>
          <p className="text-muted-foreground text-sm">Запись недоступна</p>
        </div>
        <Card className="card-cyber">
          <CardContent className="py-8 text-center">
            <Mic className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              Ваш браузер не поддерживает запись аудио
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-primary" data-testid="text-voice-notes-title">
          Голосовые заметки
        </h1>
        <p className="text-muted-foreground text-sm">Запись и воспроизведение</p>
      </div>

      <Card className="card-cyber border-primary/30 bg-primary/5">
        <CardContent className="py-3 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
            <Mic className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="text-primary font-medium text-sm">Локальное хранение</p>
            <p className="text-muted-foreground text-xs">Записи сохраняются в памяти браузера</p>
          </div>
        </CardContent>
      </Card>

      <Card className="card-cyber">
        <CardHeader>
          <CardTitle className="text-sm flex items-center gap-2">
            <Mic className="w-4 h-4 text-primary" />
            Новая запись
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input
            value={currentTitle}
            onChange={(e) => setCurrentTitle(e.target.value)}
            placeholder="Название заметки (опционально)"
            className="bg-muted border-primary/20"
            disabled={isRecording}
            data-testid="input-note-title"
          />

          <div className="flex items-center justify-center gap-4">
            {isRecording ? (
              <>
                <div className="text-2xl font-mono text-red-500 animate-pulse" data-testid="text-recording-time">
                  {formatTime(recordingTime)}
                </div>
                <Button
                  size="icon"
                  className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600"
                  onClick={stopRecording}
                  data-testid="button-stop-recording"
                >
                  <Square className="w-6 h-6" />
                </Button>
              </>
            ) : (
              <Button
                size="icon"
                className="w-16 h-16 rounded-full bg-gradient-primary"
                onClick={startRecording}
                data-testid="button-start-recording"
              >
                <Mic className="w-6 h-6" />
              </Button>
            )}
          </div>

          {isRecording && (
            <p className="text-center text-sm text-muted-foreground">
              Идёт запись... Нажмите для остановки
            </p>
          )}
        </CardContent>
      </Card>

      <div className="space-y-3">
        <h3 className="text-sm text-muted-foreground">
          Сохранённые заметки ({notes.length})
        </h3>

        {notes.length === 0 ? (
          <Card className="card-cyber">
            <CardContent className="py-8 text-center">
              <Mic className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <p className="text-muted-foreground">
                У вас пока нет голосовых заметок
              </p>
            </CardContent>
          </Card>
        ) : (
          notes.map((note) => (
            <Card 
              key={note.id} 
              className={cn("card-cyber", playingId === note.id && "border-primary")}
              data-testid={`card-note-${note.id}`}
            >
              <CardContent className="py-4">
                <div className="flex items-center gap-3">
                  <Button
                    size="icon"
                    variant={playingId === note.id ? "default" : "outline"}
                    onClick={() => playNote(note)}
                    data-testid={`button-play-${note.id}`}
                  >
                    {playingId === note.id ? (
                      <Pause className="w-4 h-4" />
                    ) : (
                      <Play className="w-4 h-4" />
                    )}
                  </Button>

                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{note.title}</div>
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                      <span>{formatDate(note.timestamp)}</span>
                      <span className="text-primary">{formatTime(note.duration)}</span>
                    </div>
                  </div>

                  <Button
                    size="icon"
                    variant="ghost"
                    className="text-destructive"
                    onClick={() => deleteNote(note.id)}
                    data-testid={`button-delete-${note.id}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}

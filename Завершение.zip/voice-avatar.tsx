import { cn } from "@/lib/utils";

type VoiceState = "idle" | "listening" | "speaking";

interface VoiceAvatarProps {
  state: VoiceState;
  className?: string;
}

export function VoiceAvatar({ state, className }: VoiceAvatarProps) {
  return (
    <div className={cn("relative w-48 h-48", className)} data-testid="voice-avatar">
      <div className="avatar-ring avatar-ring-1 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
      <div className="avatar-ring avatar-ring-2 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
      <div className="avatar-ring avatar-ring-3 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
      
      <div
        className={cn(
          "absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2",
          "w-28 h-28 rounded-full flex items-center justify-center",
          "transition-all duration-300",
          state === "idle" && "bg-gradient-primary glow-primary",
          state === "listening" && "bg-gradient-primary listening",
          state === "speaking" && "bg-gradient-success speaking"
        )}
        data-testid="avatar-core"
      >
        {state === "listening" ? (
          <Mic className="w-10 h-10 text-white" />
        ) : (
          <Bot className="w-10 h-10 text-white" />
        )}
      </div>
    </div>
  );
}

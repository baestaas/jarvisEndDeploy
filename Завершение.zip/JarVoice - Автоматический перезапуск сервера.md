# JarVoice - Автоматический перезапуск сервера

## Обзор

JarVoice настроен для автономной работы с автоматическим перезапуском каждые **24 часа**. Это обеспечивает:
- Очистку памяти и предотвращение утечек
- Стабильную работу сервиса
- Сохранение всех пользовательских сессий

## ✅ Текущая конфигурация

Сервер работает как **systemd service** с автоматическим перезапуском:
- **Статус:** Активен и работает
- **Автозапуск:** Включен (при загрузке системы)
- **Перезапуск:** Каждые 24 часа автоматически
- **Независимость:** Работает даже когда Manus закрыт

## Как это работает

### Systemd Service

Файл сервиса: `/etc/systemd/system/jarvoice.service`

Ключевые параметры:
```ini
[Service]
RuntimeMaxSec=86400    # Перезапуск каждые 24 часа (86400 секунд)
Restart=always         # Автоматический перезапуск при сбоях
RestartSec=10          # Задержка 10 секунд перед перезапуском
```

### Сохранение сессий

Все пользовательские данные хранятся в файлах:
- `.data/users.json` - данные пользователей (включая пол)
- `.data/sessions/` - сессии пользователей
- База данных PostgreSQL (если подключена)

При перезапуске сервера все сессии автоматически восстанавливаются.

## Управление сервисом

### Проверка статуса
```bash
sudo systemctl status jarvoice
```

### Остановка
```bash
sudo systemctl stop jarvoice
```

### Запуск
```bash
sudo systemctl start jarvoice
```

### Перезапуск
```bash
sudo systemctl restart jarvoice
```

### Просмотр логов в реальном времени
```bash
sudo journalctl -u jarvoice -f
```

### Просмотр последних логов
```bash
sudo journalctl -u jarvoice -n 100
```

## Установка сервиса (если нужно переустановить)

```bash
cd /home/ubuntu/Jarvis-project/Jarvis-1
sudo ./install-service.sh
```

Или вручную:

```bash
# Копирование файла сервиса
sudo cp jarvoice.service /etc/systemd/system/

# Перезагрузка systemd
sudo systemctl daemon-reload

# Включение автозапуска
sudo systemctl enable jarvoice

# Запуск сервиса
sudo systemctl start jarvoice
```

## Обновление приложения

При обновлении кода:

```bash
# 1. Пересобрать проект
cd /home/ubuntu/Jarvis-project/Jarvis-1
npm run build

# 2. Перезапустить сервис
sudo systemctl restart jarvoice
```

## Мониторинг

### Проверка здоровья сервера
```bash
curl http://localhost:5000/api/health
```

### Проверка времени работы
```bash
sudo systemctl show jarvoice --property=ActiveEnterTimestamp
```

## Логи

Логи сервера записываются в:
- `/home/ubuntu/Jarvis-project/Jarvis-1/server.log`

Для просмотра:
```bash
tail -f /home/ubuntu/Jarvis-project/Jarvis-1/server.log
```

## Устранение неполадок

### Сервис не запускается

1. Проверьте логи:
```bash
sudo journalctl -u jarvoice -n 50
```

2. Проверьте, что проект собран:
```bash
ls -la /home/ubuntu/Jarvis-project/Jarvis-1/dist/index.cjs
```

### Порт занят

```bash
# Найти процесс на порту 5000
sudo lsof -i :5000

# Убить процесс
sudo kill -9 <PID>
```

## Важные замечания

1. **Сервис работает автономно** - не требует запущенного Manus
2. **Перезапуск каждые 24 часа** - происходит автоматически
3. **Сессии сохраняются** - пользователи не теряют авторизацию
4. **Логи ротируются** - systemd автоматически управляет логами

---

*Последнее обновление: 20 декабря 2025*

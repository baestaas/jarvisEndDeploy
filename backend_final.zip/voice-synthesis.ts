// client/src/lib/voice-synthesis.ts
// Модуль для синтеза голоса Джарвиса на сервере

export async function synthesizeJarvisVoice(text: string): Promise<Blob | null> {
  try {
    const response = await fetch("/api/voice/synthesize", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text: text.substring(0, 500) }),
    });

    if (!response.ok) {
      console.error(`Voice synthesis server error: ${response.status}`);
      return null;
    }

    const audioBlob = await response.blob();
    return audioBlob;
  } catch (error) {
    console.error("Voice synthesis error:", error);
    return null;
  }
}

export async function playAudioBlob(audioBlob: Blob): Promise<void> {
  return new Promise((resolve, reject) => {
    const audioUrl = URL.createObjectURL(audioBlob);
    const audio = new Audio(audioUrl);
    audio.volume = 1.0;

    let hasEnded = false;

    const handleEnd = () => {
      if (!hasEnded) {
        hasEnded = true;
        URL.revokeObjectURL(audioUrl);
        resolve();
      }
    };

    const handleError = (error: Event) => {
      console.error("Audio playback error:", error);
      if (!hasEnded) {
        hasEnded = true;
        URL.revokeObjectURL(audioUrl);
        reject(error);
      }
    };

    audio.onended = handleEnd;
    audio.onerror = handleError;

    // Таймаут на случай если onended не сработает
    const timeoutId = setTimeout(() => {
      if (!hasEnded) {
        hasEnded = true;
        URL.revokeObjectURL(audioUrl);
        resolve();
      }
    }, 60000); // 60 секунд максимум

    audio
      .play()
      .catch((error) => {
        clearTimeout(timeoutId);
        handleError(new Event("play-error"));
      });
  });
}

export async function speakWithJarvisVoice(text: string): Promise<void> {
  try {
    const audioBlob = await synthesizeJarvisVoice(text);
    if (audioBlob) {
      await playAudioBlob(audioBlob);
    } else {
      throw new Error("Failed to synthesize voice");
    }
  } catch (error) {
    console.error("Jarvis voice synthesis failed:", error);
    throw error;
  }
}

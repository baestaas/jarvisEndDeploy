import { useState } from "react";
import { cn } from "@/lib/utils";
import { Loader2, X, ZoomIn } from "lucide-react";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface ResponseAreaProps {
  text: string;
  className?: string;
  imageUrl?: string;
  isGeneratingImage?: boolean;
}

export function ResponseArea({ text, className, imageUrl, isGeneratingImage }: ResponseAreaProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div 
      className={cn(
        "card-cyber p-6 min-h-24",
        className
      )}
      data-testid="response-area"
    >
      <p className="text-base leading-relaxed whitespace-pre-wrap" data-testid="text-response">
        {text}
      </p>
      
      {isGeneratingImage && (
        <div className="flex items-center gap-3 mt-4 text-primary" data-testid="image-loading">
          <Loader2 className="w-6 h-6 animate-spin" />
          <span className="text-sm">Генерация изображения...</span>
        </div>
      )}
      
      {imageUrl && !isGeneratingImage && (
        <div className="mt-4">
          <div 
            className="relative group cursor-pointer rounded-md overflow-hidden"
            onClick={() => setIsModalOpen(true)}
            data-testid="generated-image-container"
          >
            <img 
              src={imageUrl} 
              alt="Сгенерированное изображение" 
              className="w-full max-w-md rounded-md border border-primary/20 transition-transform duration-200 group-hover:scale-[1.02]"
              data-testid="generated-image"
            />
            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
              <ZoomIn className="w-8 h-8 text-white" />
            </div>
          </div>
        </div>
      )}

      <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
        <DialogContent className="max-w-4xl p-2 bg-card border-primary/20">
          <button 
            onClick={() => setIsModalOpen(false)}
            className="absolute top-3 right-3 z-10 p-1 rounded-full bg-black/50 text-white"
            data-testid="button-close-modal"
          >
            <X className="w-5 h-5" />
          </button>
          {imageUrl && (
            <img 
              src={imageUrl} 
              alt="Сгенерированное изображение" 
              className="w-full h-auto rounded-md"
              data-testid="modal-image"
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

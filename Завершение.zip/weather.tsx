      console.error("Weather fetch error:", err);
      try {
        const response = await fetch(`/api/weather?city=${encodeURIComponent(city)}`);
        const data = await response.json();
        if (data.success) {
          setWeather(data.weather);
        }
      } catch {
        console.error("Fallback weather fetch error");
      }
    } finally {
      setIsLoading(false);
    }
  };

  const requestGeolocation = () => {
    if (!navigator.geolocation) {
      setLocationStatus("unavailable");
      setCity(DEFAULT_CITY);
      fetchWeather();
      return;
    }

    setLocationStatus("loading");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocationStatus("granted");
        fetchWeatherByCoords(position.coords.latitude, position.coords.longitude);
      },
      (error) => {
        console.error("Geolocation error:", error);
        setLocationStatus("denied");
        setCity(DEFAULT_CITY);
        fetchWeather();
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000,
      }
    );
  };

  useEffect(() => {
    const savedCity = localStorage.getItem(STORAGE_KEY);
    if (savedCity) {
      setCity(savedCity);
      fetchWeather();
    } else {
      requestGeolocation();
    }
  }, []);

  const handleUseLocation = () => {
    requestGeolocation();
  };

  const getLocationStatusText = () => {
    switch (locationStatus) {
      case "loading":
        return "Определение местоположения...";
      case "granted":
        return "Местоположение определено";
      case "denied":
        return "Доступ к геолокации запрещён";
      case "unavailable":
        return "Геолокация недоступна";
      default:
        return null;
    }
  };

  const getLocationStatusVariant = (): "default" | "secondary" | "destructive" | "outline" => {
    switch (locationStatus) {
      case "granted":
        return "default";
      case "denied":
      case "unavailable":
        return "destructive";
      default:
        return "secondary";
    }
  };

  const WeatherIcon = getWeatherIcon(weather.condition);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-primary" data-testid="text-weather-title">
          Погода
        </h1>
        <p className="text-muted-foreground text-sm">Прогноз погоды</p>
      </div>

      <div className="flex flex-col gap-2">
        <div className="flex gap-2">
          <Input
            value={city}
            onChange={(e) => setCity(e.target.value)}
import { type User, type InsertUser, type FinanceRecord, type InsertFinanceRecord, type Event, type InsertEvent, type Reminder, type InsertReminder, type Directive, type InsertDirective, type PushSubscription, type InsertPushSubscription, type FamilyGroup, type InsertFamilyGroup, type FamilyMember, type InsertFamilyMember, type SharedList, type InsertSharedList, type SharedListItem, type InsertSharedListItem, users, financeRecords, events, reminders, directives, pushSubscriptions, familyGroups, familyMembers, sharedLists, sharedListItems } from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";
import * as fs from "fs";
import * as path from "path";

// File-based persistence for users
const DATA_DIR = path.join(process.cwd(), '.data');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function loadUsersFromFile(): Map<string, any> {
  ensureDataDir();
  try {
    if (fs.existsSync(USERS_FILE)) {
      const data = JSON.parse(fs.readFileSync(USERS_FILE, 'utf-8'));
      console.log('[Storage] Loaded', Object.keys(data).length, 'users from file');
      return new Map(Object.entries(data));
    }
  } catch (e) {
    console.error('[Storage] Error loading users:', e);
  }
  return new Map();
}

function saveUsersToFile(users: Map<string, any>) {
  ensureDataDir();
  const data = Object.fromEntries(users);
  fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 2));
  console.log('[Storage] Saved', users.size, 'users to file');
}
import { eq, and, lte, sql, or } from "drizzle-orm";

export interface FamilyMemberWithUsername extends FamilyMember {
  username: string;
}

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(user: InsertUser): Promise<User>;
  updateUserRole(id: string, role: string): Promise<User | undefined>;
  validatePassword(user: User, password: string): Promise<boolean>;
  isFirstUser(): Promise<boolean>;
  updateUser2FA(id: string, updates: { twoFactorEnabled?: boolean; twoFactorSecret?: string | null; backupCodes?: string[] | null }): Promise<User | undefined>;
  updateUserTelegram(id: string, updates: { telegramChatId?: string | null; telegramLinkCode?: string | null; telegramLinked?: boolean }): Promise<User | undefined>;
  getUserByTelegramLinkCode(code: string): Promise<User | undefined>;
  getUserByTelegramChatId(chatId: string): Promise<User | undefined>;
  updateUserStripe(id: string, updates: { stripeCustomerId?: string | null; stripeSubscriptionId?: string | null }): Promise<User | undefined>;
  
  getFinanceRecords(userId: string): Promise<FinanceRecord[]>;
  createFinanceRecord(record: InsertFinanceRecord): Promise<FinanceRecord>;
  
  getEvents(userId: string): Promise<Event[]>;
  createEvent(event: InsertEvent): Promise<Event>;
  
  getReminders(userId: string): Promise<Reminder[]>;
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  updateReminder(id: string, updates: Partial<Reminder>): Promise<Reminder | undefined>;
  deleteReminder(id: string): Promise<boolean>;
  
  getDirectives(): Promise<Directive[]>;
  createDirective(directive: InsertDirective): Promise<Directive>;
  updateDirective(id: string, updates: Partial<Directive>): Promise<Directive | undefined>;
  deleteDirective(id: string): Promise<boolean>;
  
  createPushSubscription(subscription: InsertPushSubscription): Promise<PushSubscription>;
  getPushSubscriptionsByUser(userId: string): Promise<PushSubscription[]>;
  deletePushSubscription(endpoint: string): Promise<boolean>;
  getUnnotifiedReminders(): Promise<Reminder[]>;
  getUpcomingEvents(minutes: number): Promise<Event[]>;
  updateEvent(id: string, updates: Partial<Event>): Promise<Event | undefined>;
  
  createFamilyGroup(ownerId: string, name: string): Promise<FamilyGroup>;
  getFamilyGroup(groupId: string): Promise<FamilyGroup | undefined>;
  getFamilyGroupByInviteCode(code: string): Promise<FamilyGroup | undefined>;
  getUserFamilyGroups(userId: string): Promise<FamilyGroup[]>;
  addFamilyMember(groupId: string, userId: string, role: string): Promise<FamilyMember>;
  removeFamilyMember(groupId: string, userId: string): Promise<boolean>;
  getGroupMembers(groupId: string): Promise<FamilyMemberWithUsername[]>;
  createSharedList(groupId: string, name: string, listType: string): Promise<SharedList>;
  getSharedLists(groupId: string): Promise<SharedList[]>;
  getSharedListItems(listId: string): Promise<SharedListItem[]>;
  addSharedListItem(listId: string, text: string, userId: string): Promise<SharedListItem>;
  toggleSharedListItem(itemId: string): Promise<SharedListItem | undefined>;
  deleteSharedListItem(itemId: string): Promise<boolean>;
  getSharedListItem(itemId: string): Promise<SharedListItem | undefined>;
  getSharedList(listId: string): Promise<SharedList | undefined>;
}

export class MemoryStorage implements IStorage {
  private users: Map<string, User> = loadUsersFromFile();
  private financeRecords: Map<string, FinanceRecord> = new Map();
  private events: Map<string, Event> = new Map();
  private reminders: Map<string, Reminder> = new Map();
  private directives: Map<string, Directive> = new Map();
  private pushSubs: Map<string, PushSubscription> = new Map();
  private familyGroupsMap: Map<string, FamilyGroup> = new Map();
  private familyMembersMap: Map<string, FamilyMember> = new Map();
  private sharedListsMap: Map<string, SharedList> = new Map();
  private sharedListItemsMap: Map<string, SharedListItem> = new Map();

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.username === username);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.email === email);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const hashedPassword = await bcrypt.hash(insertUser.passwordHash, 10);
    
    const newUser: User = {
      id,
      username: insertUser.username,
      email: insertUser.email,
      passwordHash: hashedPassword,
      role: insertUser.role || "user",
      gender: (insertUser as any).gender || "male",
      preferences: "{}",
      createdAt: new Date(),
    };
    
    this.users.set(id, newUser);
    saveUsersToFile(this.users);
    return newUser;
  }

  async updateUserRole(id: string, role: string): Promise<User | undefined> {
    const user = this.users.get(id);
    if (user) {
      user.role = role;
      this.users.set(id, user);
      saveUsersToFile(this.users);
    }
    return user;
  }

  async validatePassword(user: User, password: string): Promise<boolean> {
    return bcrypt.compare(password, user.passwordHash);
  }

  async isFirstUser(): Promise<boolean> {
    return this.users.size === 0;
  }

  async updateUser2FA(id: string, updates: { twoFactorEnabled?: boolean; twoFactorSecret?: string | null; backupCodes?: string[] | null }): Promise<User | undefined> {
    const user = this.users.get(id);
    if (user) {
      if (updates.twoFactorEnabled !== undefined) user.twoFactorEnabled = updates.twoFactorEnabled;
      if (updates.twoFactorSecret !== undefined) user.twoFactorSecret = updates.twoFactorSecret;
      if (updates.backupCodes !== undefined) user.backupCodes = updates.backupCodes;
      this.users.set(id, user);
      saveUsersToFile(this.users);
    }
    return user;
  }

  async updateUserTelegram(id: string, updates: { telegramChatId?: string | null; telegramLinkCode?: string | null; telegramLinked?: boolean }): Promise<User | undefined> {
    const user = this.users.get(id);
    if (user) {
      if (updates.telegramChatId !== undefined) user.telegramChatId = updates.telegramChatId;
      if (updates.telegramLinkCode !== undefined) user.telegramLinkCode = updates.telegramLinkCode;
      if (updates.telegramLinked !== undefined) user.telegramLinked = updates.telegramLinked;
      this.users.set(id, user);
      saveUsersToFile(this.users);
    }
    return user;
  }

  async getUserByTelegramLinkCode(code: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.telegramLinkCode === code);
  }

  async getUserByTelegramChatId(chatId: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(u => u.telegramChatId === chatId);
  }

  async updateUserStripe(id: string, updates: { stripeCustomerId?: string | null; stripeSubscriptionId?: string | null }): Promise<User | undefined> {
    const user = this.users.get(id);
    if (user) {
      if (updates.stripeCustomerId !== undefined) user.stripeCustomerId = updates.stripeCustomerId;
      if (updates.stripeSubscriptionId !== undefined) user.stripeSubscriptionId = updates.stripeSubscriptionId;
      this.users.set(id, user);
      saveUsersToFile(this.users);
    }
    return user;
  }

  async getFinanceRecords(userId: string): Promise<FinanceRecord[]> {
    return Array.from(this.financeRecords.values()).filter(r => r.userId === userId);
  }

  async createFinanceRecord(record: InsertFinanceRecord): Promise<FinanceRecord> {
    const id = randomUUID();
    const newRecord: FinanceRecord = {
      id,
      userId: record.userId,
      amount: record.amount,
      category: record.category,
      recordType: record.recordType || "expense",
      description: record.description ?? null,
      date: record.date ?? new Date(),
    };
    this.financeRecords.set(id, newRecord);
    return newRecord;
  }

  async getEvents(userId: string): Promise<Event[]> {
    return Array.from(this.events.values()).filter(e => e.userId === userId);
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    const id = randomUUID();
    const newEvent: Event = {
      id,
      userId: event.userId,
      title: event.title,
      description: event.description ?? null,
      eventType: event.eventType || "meeting",
      startTime: event.startTime,
      endTime: event.endTime ?? null,
      location: event.location ?? null,
      isVirtual: event.isVirtual ?? false,
      createdAt: new Date(),
    };
    this.events.set(id, newEvent);
    return newEvent;
  }

  async getReminders(userId: string): Promise<Reminder[]> {
    return Array.from(this.reminders.values()).filter(r => r.userId === userId);
  }

  async createReminder(reminder: InsertReminder): Promise<Reminder> {
    const id = randomUUID();
    const newReminder: Reminder = {
      id,
      userId: reminder.userId,
      title: reminder.title,
      description: reminder.description ?? null,
      remindAt: reminder.remindAt,
      isCompleted: reminder.isCompleted ?? false,
      isNotified: reminder.isNotified ?? false,
      repeatType: reminder.repeatType ?? null,
      createdAt: new Date(),
    };
    this.reminders.set(id, newReminder);
    return newReminder;
  }

  async updateReminder(id: string, updates: Partial<Reminder>): Promise<Reminder | undefined> {
    const reminder = this.reminders.get(id);
    if (reminder) {
      const updated = { ...reminder, ...updates };
      this.reminders.set(id, updated);
      return updated;
    }
    return undefined;
  }

  async deleteReminder(id: string): Promise<boolean> {
    return this.reminders.delete(id);
  }

  async getDirectives(): Promise<Directive[]> {
    return Array.from(this.directives.values()).sort((a, b) => (b.priority ?? 0) - (a.priority ?? 0));
  }

  async createDirective(directive: InsertDirective): Promise<Directive> {
    const id = randomUUID();
    const newDirective: Directive = {
      id,
      name: directive.name,
      description: directive.description ?? null,
      priority: directive.priority ?? 0,
      isActive: directive.isActive ?? true,
      createdBy: directive.createdBy,
      createdAt: new Date(),
    };
    this.directives.set(id, newDirective);
    return newDirective;
  }

  async updateDirective(id: string, updates: Partial<Directive>): Promise<Directive | undefined> {
    const directive = this.directives.get(id);
    if (directive) {
      const updated = { ...directive, ...updates };
      this.directives.set(id, updated);
      return updated;
    }
    return undefined;
  }

  async deleteDirective(id: string): Promise<boolean> {
    return this.directives.delete(id);
  }

  async createPushSubscription(subscription: InsertPushSubscription): Promise<PushSubscription> {
    const id = randomUUID();
    const newSub: PushSubscription = {
      id,
      userId: subscription.userId,
      endpoint: subscription.endpoint,
      p256dh: subscription.p256dh,
      auth: subscription.auth,
      createdAt: new Date(),
    };
    this.pushSubs.set(id, newSub);
    return newSub;
  }

  async getPushSubscriptionsByUser(userId: string): Promise<PushSubscription[]> {
    return Array.from(this.pushSubs.values()).filter(s => s.userId === userId);
  }

  async deletePushSubscription(endpoint: string): Promise<boolean> {
    for (const [id, sub] of this.pushSubs.entries()) {
      if (sub.endpoint === endpoint) {
        this.pushSubs.delete(id);
        return true;
      }
    }
    return false;
  }

  async getUnnotifiedReminders(): Promise<Reminder[]> {
    const now = new Date();
    return Array.from(this.reminders.values()).filter(
      r => !r.isNotified && !r.isCompleted && r.remindAt <= now
    );
  }

  async getUpcomingEvents(minutes: number): Promise<Event[]> {
    const now = new Date();
    const threshold = new Date(now.getTime() + minutes * 60 * 1000);
    return Array.from(this.events.values()).filter(
      e => !e.isNotified && e.startTime >= now && e.startTime <= threshold
    );
  }

  async updateEvent(id: string, updates: Partial<Event>): Promise<Event | undefined> {
    const event = this.events.get(id);
    if (event) {
      const updated = { ...event, ...updates };
      this.events.set(id, updated);
      return updated;
    }
    return undefined;
  }

  private generateInviteCode(): string {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code = "";
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  async createFamilyGroup(ownerId: string, name: string): Promise<FamilyGroup> {
    const id = randomUUID();
    const inviteCode = this.generateInviteCode();
    const group: FamilyGroup = {
      id,
      ownerId,
      name,
      inviteCode,
      createdAt: new Date(),
    };
    this.familyGroupsMap.set(id, group);
    await this.addFamilyMember(id, ownerId, "owner");
    return group;
  }

  async getFamilyGroup(groupId: string): Promise<FamilyGroup | undefined> {
    return this.familyGroupsMap.get(groupId);
  }

  async getFamilyGroupByInviteCode(code: string): Promise<FamilyGroup | undefined> {
    return Array.from(this.familyGroupsMap.values()).find(g => g.inviteCode === code);
  }

  async getUserFamilyGroups(userId: string): Promise<FamilyGroup[]> {
    const memberGroupIds = Array.from(this.familyMembersMap.values())
      .filter(m => m.userId === userId)
      .map(m => m.groupId);
    return Array.from(this.familyGroupsMap.values()).filter(g => memberGroupIds.includes(g.id));
  }

  async addFamilyMember(groupId: string, userId: string, role: string): Promise<FamilyMember> {
    const id = randomUUID();
    const member: FamilyMember = {
      id,
      groupId,
      userId,
      role,
      joinedAt: new Date(),
    };
    this.familyMembersMap.set(id, member);
    return member;
  }

  async removeFamilyMember(groupId: string, userId: string): Promise<boolean> {
    for (const [id, member] of this.familyMembersMap.entries()) {
      if (member.groupId === groupId && member.userId === userId) {
        this.familyMembersMap.delete(id);
        return true;
      }
    }
    return false;
  }

  async getGroupMembers(groupId: string): Promise<FamilyMemberWithUsername[]> {
    const members = Array.from(this.familyMembersMap.values()).filter(m => m.groupId === groupId);
    return members.map(m => {
      const user = this.users.get(m.userId);
      return { ...m, username: user?.username || "Неизвестный" };
    });
  }

  async createSharedList(groupId: string, name: string, listType: string): Promise<SharedList> {
    const id = randomUUID();
    const list: SharedList = {
      id,
      groupId,
      name,
      listType,
      createdAt: new Date(),
    };
    this.sharedListsMap.set(id, list);
    return list;
  }

  async getSharedLists(groupId: string): Promise<SharedList[]> {
    return Array.from(this.sharedListsMap.values()).filter(l => l.groupId === groupId);
  }

  async getSharedListItems(listId: string): Promise<SharedListItem[]> {
    return Array.from(this.sharedListItemsMap.values()).filter(i => i.listId === listId);
  }

  async addSharedListItem(listId: string, text: string, userId: string): Promise<SharedListItem> {
    const id = randomUUID();
    const item: SharedListItem = {
      id,
      listId,
      text,
      completed: false,
      createdBy: userId,
      createdAt: new Date(),
    };
    this.sharedListItemsMap.set(id, item);
    return item;
  }

  async toggleSharedListItem(itemId: string): Promise<SharedListItem | undefined> {
    const item = this.sharedListItemsMap.get(itemId);
    if (item) {
      item.completed = !item.completed;
      this.sharedListItemsMap.set(itemId, item);
      return item;
    }
    return undefined;
  }

  async deleteSharedListItem(itemId: string): Promise<boolean> {
    return this.sharedListItemsMap.delete(itemId);
  }

  async getSharedListItem(itemId: string): Promise<SharedListItem | undefined> {
    return this.sharedListItemsMap.get(itemId);
  }

  async getSharedList(listId: string): Promise<SharedList | undefined> {
    return this.sharedListsMap.get(listId);
  }
}

export class DatabaseStorage implements IStorage {
  private db: any;
  private fallback: MemoryStorage;
  private useDb: boolean = true;

  constructor() {
    this.fallback = new MemoryStorage();
    this.initDb();
  }

  private async initDb() {
    try {
      const { db } = await import("./db");
      this.db = db;
      const result = await db.select().from(users).limit(1);
      console.log("Database storage initialized successfully");
    } catch (error) {
      console.error("Database unavailable, using memory storage:", (error as Error).message);
      this.useDb = false;
    }
  }

  async getUser(id: string): Promise<User | undefined> {
    if (!this.useDb) return this.fallback.getUser(id);
    try {
      const result = await this.db.select().from(users).where(eq(users.id, id));
      return result[0];
    } catch (error) {
      console.error("DB error in getUser:", error);
      return this.fallback.getUser(id);
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    if (!this.useDb) return this.fallback.getUserByUsername(username);
    try {
      const result = await this.db.select().from(users).where(eq(users.username, username));
      return result[0];
    } catch (error) {
      console.error("DB error in getUserByUsername:", error);
      return this.fallback.getUserByUsername(username);
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    if (!this.useDb) return this.fallback.getUserByEmail(email);
    try {
      const result = await this.db.select().from(users).where(eq(users.email, email));
      return result[0];
    } catch (error) {
      console.error("DB error in getUserByEmail:", error);
      return this.fallback.getUserByEmail(email);
    }
  }

  async getAllUsers(): Promise<User[]> {
    if (!this.useDb) return this.fallback.getAllUsers();
    try {
      return await this.db.select().from(users);
    } catch (error) {
      console.error("DB error in getAllUsers:", error);
      return this.fallback.getAllUsers();
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    if (!this.useDb) return this.fallback.createUser(insertUser);
    try {
      const id = randomUUID();
      const hashedPassword = await bcrypt.hash(insertUser.passwordHash, 10);
      
      const newUser = {
        id,
        username: insertUser.username,
        email: insertUser.email,
        passwordHash: hashedPassword,
        role: insertUser.role || "user",
        preferences: "{}",
      };
      
      await this.db.insert(users).values(newUser);
      
      const result = await this.getUser(id);
      return result!;
    } catch (error) {
      console.error("DB error in createUser, falling back to memory:", error);
      this.useDb = false;
      return this.fallback.createUser(insertUser);
    }
  }

  async updateUserRole(id: string, role: string): Promise<User | undefined> {
    if (!this.useDb) return this.fallback.updateUserRole(id, role);
    try {
      await this.db.update(users).set({ role }).where(eq(users.id, id));
      return this.getUser(id);
    } catch (error) {
      return this.fallback.updateUserRole(id, role);
    }
  }

  async validatePassword(user: User, password: string): Promise<boolean> {
    return bcrypt.compare(password, user.passwordHash);
  }

  async isFirstUser(): Promise<boolean> {
    if (!this.useDb) return this.fallback.isFirstUser();
    try {
      const result = await this.db.select().from(users).limit(1);
      return result.length === 0;
    } catch (error) {
      console.error("DB error in isFirstUser:", error);
      return this.fallback.isFirstUser();
    }
  }

  async updateUser2FA(id: string, updates: { twoFactorEnabled?: boolean; twoFactorSecret?: string | null; backupCodes?: string[] | null }): Promise<User | undefined> {
    if (!this.useDb) return this.fallback.updateUser2FA(id, updates);
    try {
      await this.db.update(users).set(updates).where(eq(users.id, id));
      return this.getUser(id);
    } catch (error) {
      console.error("DB error in updateUser2FA:", error);
      return this.fallback.updateUser2FA(id, updates);
    }
  }

  async updateUserTelegram(id: string, updates: { telegramChatId?: string | null; telegramLinkCode?: string | null; telegramLinked?: boolean }): Promise<User | undefined> {
    if (!this.useDb) return this.fallback.updateUserTelegram(id, updates);
    try {
      await this.db.update(users).set(updates).where(eq(users.id, id));
      return this.getUser(id);
    } catch (error) {
      console.error("DB error in updateUserTelegram:", error);
      return this.fallback.updateUserTelegram(id, updates);
    }
  }

  async getUserByTelegramLinkCode(code: string): Promise<User | undefined> {
    if (!this.useDb) return this.fallback.getUserByTelegramLinkCode(code);
    try {
      const result = await this.db.select().from(users).where(eq(users.telegramLinkCode, code));
      return result[0];
    } catch (error) {
      console.error("DB error in getUserByTelegramLinkCode:", error);
      return this.fallback.getUserByTelegramLinkCode(code);
    }
  }

  async getUserByTelegramChatId(chatId: string): Promise<User | undefined> {
    if (!this.useDb) return this.fallback.getUserByTelegramChatId(chatId);
    try {
      const result = await this.db.select().from(users).where(eq(users.telegramChatId, chatId));
      return result[0];
    } catch (error) {
      console.error("DB error in getUserByTelegramChatId:", error);
      return this.fallback.getUserByTelegramChatId(chatId);
    }
  }

  async updateUserStripe(id: string, updates: { stripeCustomerId?: string | null; stripeSubscriptionId?: string | null }): Promise<User | undefined> {
    if (!this.useDb) return this.fallback.updateUserStripe(id, updates);
    try {
      await this.db.update(users).set(updates).where(eq(users.id, id));
      return this.getUser(id);
    } catch (error) {
      console.error("DB error in updateUserStripe:", error);
      return this.fallback.updateUserStripe(id, updates);
    }
  }

  async getFinanceRecords(userId: string): Promise<FinanceRecord[]> {
    if (!this.useDb) return this.fallback.getFinanceRecords(userId);
    try {
      return this.db.select().from(financeRecords).where(eq(financeRecords.userId, userId));
    } catch (error) {
      return this.fallback.getFinanceRecords(userId);
    }
  }

  async createFinanceRecord(record: InsertFinanceRecord): Promise<FinanceRecord> {
    if (!this.useDb) return this.fallback.createFinanceRecord(record);
    try {
      const id = randomUUID();
      const newRecord = { ...record, id };
      await this.db.insert(financeRecords).values(newRecord);
      const result = await this.db.select().from(financeRecords).where(eq(financeRecords.id, id));
      return result[0];
    } catch (error) {
      return this.fallback.createFinanceRecord(record);
    }
  }

  async getEvents(userId: string): Promise<Event[]> {
    if (!this.useDb) return this.fallback.getEvents(userId);
    try {
      return this.db.select().from(events).where(eq(events.userId, userId));
    } catch (error) {
      return this.fallback.getEvents(userId);
    }
  }

  async createEvent(event: InsertEvent): Promise<Event> {
    if (!this.useDb) return this.fallback.createEvent(event);
    try {
      const id = randomUUID();
      const newEvent = { ...event, id };
      await this.db.insert(events).values(newEvent);
      const result = await this.db.select().from(events).where(eq(events.id, id));
      return result[0];
    } catch (error) {
      return this.fallback.createEvent(event);
    }
  }

  async getReminders(userId: string): Promise<Reminder[]> {
    if (!this.useDb) return this.fallback.getReminders(userId);
    try {
      return this.db.select().from(reminders).where(eq(reminders.userId, userId));
    } catch (error) {
      return this.fallback.getReminders(userId);
    }
  }

  async createReminder(reminder: InsertReminder): Promise<Reminder> {
    if (!this.useDb) return this.fallback.createReminder(reminder);
    try {
      const id = randomUUID();
      const newReminder = { ...reminder, id };
      await this.db.insert(reminders).values(newReminder);
      const result = await this.db.select().from(reminders).where(eq(reminders.id, id));
      return result[0];
    } catch (error) {
      return this.fallback.createReminder(reminder);
    }
  }

  async updateReminder(id: string, updates: Partial<Reminder>): Promise<Reminder | undefined> {
    if (!this.useDb) return this.fallback.updateReminder(id, updates);
    try {
      await this.db.update(reminders).set(updates).where(eq(reminders.id, id));
      const result = await this.db.select().from(reminders).where(eq(reminders.id, id));
      return result[0];
    } catch (error) {
      return this.fallback.updateReminder(id, updates);
    }
  }

  async deleteReminder(id: string): Promise<boolean> {
    if (!this.useDb) return this.fallback.deleteReminder(id);
    try {
      await this.db.delete(reminders).where(eq(reminders.id, id));
      return true;
    } catch (error) {
      return this.fallback.deleteReminder(id);
    }
  }

  async getDirectives(): Promise<Directive[]> {
    if (!this.useDb) return this.fallback.getDirectives();
    try {
      const result = await this.db.select().from(directives);
      return result.sort((a: Directive, b: Directive) => (b.priority ?? 0) - (a.priority ?? 0));
    } catch (error) {
      return this.fallback.getDirectives();
    }
  }

  async createDirective(directive: InsertDirective): Promise<Directive> {
    if (!this.useDb) return this.fallback.createDirective(directive);
    try {
      const id = randomUUID();
      const newDirective = { ...directive, id };
      await this.db.insert(directives).values(newDirective);
      const result = await this.db.select().from(directives).where(eq(directives.id, id));
      return result[0];
    } catch (error) {
      return this.fallback.createDirective(directive);
    }
  }

  async updateDirective(id: string, updates: Partial<Directive>): Promise<Directive | undefined> {
    if (!this.useDb) return this.fallback.updateDirective(id, updates);
    try {
      await this.db.update(directives).set(updates).where(eq(directives.id, id));
      const result = await this.db.select().from(directives).where(eq(directives.id, id));
      return result[0];
    } catch (error) {
      return this.fallback.updateDirective(id, updates);
    }
  }

  async deleteDirective(id: string): Promise<boolean> {
    if (!this.useDb) return this.fallback.deleteDirective(id);
    try {
      await this.db.delete(directives).where(eq(directives.id, id));
      return true;
    } catch (error) {
      return this.fallback.deleteDirective(id);
    }
  }

  async createPushSubscription(subscription: InsertPushSubscription): Promise<PushSubscription> {
    if (!this.useDb) return this.fallback.createPushSubscription(subscription);
    try {
      const id = randomUUID();
      const newSub = { ...subscription, id };
      await this.db.insert(pushSubscriptions).values(newSub);
      const result = await this.db.select().from(pushSubscriptions).where(eq(pushSubscriptions.id, id));
      return result[0];
    } catch (error) {
      return this.fallback.createPushSubscription(subscription);
    }
  }

  async getPushSubscriptionsByUser(userId: string): Promise<PushSubscription[]> {
    if (!this.useDb) return this.fallback.getPushSubscriptionsByUser(userId);
    try {
      return this.db.select().from(pushSubscriptions).where(eq(pushSubscriptions.userId, userId));
    } catch (error) {
      return this.fallback.getPushSubscriptionsByUser(userId);
    }
  }

  async deletePushSubscription(endpoint: string): Promise<boolean> {
    if (!this.useDb) return this.fallback.deletePushSubscription(endpoint);
    try {
      await this.db.delete(pushSubscriptions).where(eq(pushSubscriptions.endpoint, endpoint));
      return true;
    } catch (error) {
      return this.fallback.deletePushSubscription(endpoint);
    }
  }

  async getUnnotifiedReminders(): Promise<Reminder[]> {
    if (!this.useDb) return this.fallback.getUnnotifiedReminders();
    try {
      const now = new Date();
      return this.db.select().from(reminders).where(
        and(
          eq(reminders.isNotified, false),
          eq(reminders.isCompleted, false),
          lte(reminders.remindAt, now)
        )
      );
    } catch (error) {
      return this.fallback.getUnnotifiedReminders();
    }
  }

  async getUpcomingEvents(minutes: number): Promise<Event[]> {
    if (!this.useDb) return this.fallback.getUpcomingEvents(minutes);
    try {
      const now = new Date();
      const threshold = new Date(now.getTime() + minutes * 60 * 1000);
      return this.db.select().from(events).where(
        and(
          eq(events.isNotified, false),
          lte(events.startTime, threshold)
        )
      );
    } catch (error) {
      return this.fallback.getUpcomingEvents(minutes);
    }
  }

  async updateEvent(id: string, updates: Partial<Event>): Promise<Event | undefined> {
    if (!this.useDb) return this.fallback.updateEvent(id, updates);
    try {
      await this.db.update(events).set(updates).where(eq(events.id, id));
      const result = await this.db.select().from(events).where(eq(events.id, id));
      return result[0];
    } catch (error) {
      return this.fallback.updateEvent(id, updates);
    }
  }

  private generateInviteCode(): string {
    const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    let code = "";
    for (let i = 0; i < 8; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  private async generateUniqueInviteCode(): Promise<string> {
    const maxAttempts = 10;
    for (let i = 0; i < maxAttempts; i++) {
      const code = this.generateInviteCode();
      const existing = await this.getFamilyGroupByInviteCode(code);
      if (!existing) return code;
    }
    return this.generateInviteCode() + randomUUID().substring(0, 2).toUpperCase();
  }

  async createFamilyGroup(ownerId: string, name: string): Promise<FamilyGroup> {
    if (!this.useDb) return this.fallback.createFamilyGroup(ownerId, name);
    try {
      const id = randomUUID();
      const inviteCode = await this.generateUniqueInviteCode();
      const newGroup = { id, ownerId, name, inviteCode };
      await this.db.insert(familyGroups).values(newGroup);
      await this.addFamilyMember(id, ownerId, "owner");
      const result = await this.db.select().from(familyGroups).where(eq(familyGroups.id, id));
      return result[0];
    } catch (error) {
      console.error("DB error in createFamilyGroup:", error);
      return this.fallback.createFamilyGroup(ownerId, name);
    }
  }

  async getFamilyGroup(groupId: string): Promise<FamilyGroup | undefined> {
    if (!this.useDb) return this.fallback.getFamilyGroup(groupId);
    try {
      const result = await this.db.select().from(familyGroups).where(eq(familyGroups.id, groupId));
      return result[0];
    } catch (error) {
      return this.fallback.getFamilyGroup(groupId);
    }
  }

  async getFamilyGroupByInviteCode(code: string): Promise<FamilyGroup | undefined> {
    if (!this.useDb) return this.fallback.getFamilyGroupByInviteCode(code);
    try {
      const result = await this.db.select().from(familyGroups).where(eq(familyGroups.inviteCode, code));
      return result[0];
    } catch (error) {
      return this.fallback.getFamilyGroupByInviteCode(code);
    }
  }

  async getUserFamilyGroups(userId: string): Promise<FamilyGroup[]> {
    if (!this.useDb) return this.fallback.getUserFamilyGroups(userId);
    try {
      const memberships = await this.db.select().from(familyMembers).where(eq(familyMembers.userId, userId));
      const groupIds = memberships.map((m: FamilyMember) => m.groupId);
      if (groupIds.length === 0) return [];
      const groups = await this.db.select().from(familyGroups).where(
        or(...groupIds.map((gid: string) => eq(familyGroups.id, gid)))
      );
      return groups;
    } catch (error) {
      console.error("DB error in getUserFamilyGroups:", error);
      return this.fallback.getUserFamilyGroups(userId);
    }
  }

  async addFamilyMember(groupId: string, userId: string, role: string): Promise<FamilyMember> {
    if (!this.useDb) return this.fallback.addFamilyMember(groupId, userId, role);
    try {
      const id = randomUUID();
      const newMember = { id, groupId, userId, role };
      await this.db.insert(familyMembers).values(newMember);
      const result = await this.db.select().from(familyMembers).where(eq(familyMembers.id, id));
      return result[0];
    } catch (error) {
      console.error("DB error in addFamilyMember:", error);
      return this.fallback.addFamilyMember(groupId, userId, role);
    }
  }

  async removeFamilyMember(groupId: string, userId: string): Promise<boolean> {
    if (!this.useDb) return this.fallback.removeFamilyMember(groupId, userId);
    try {
      await this.db.delete(familyMembers).where(
        and(eq(familyMembers.groupId, groupId), eq(familyMembers.userId, userId))
      );
      return true;
    } catch (error) {
      return this.fallback.removeFamilyMember(groupId, userId);
    }
  }

  async getGroupMembers(groupId: string): Promise<FamilyMemberWithUsername[]> {
    if (!this.useDb) return this.fallback.getGroupMembers(groupId);
    try {
      const result = await this.db
        .select({
          id: familyMembers.id,
          groupId: familyMembers.groupId,
          userId: familyMembers.userId,
          role: familyMembers.role,
          joinedAt: familyMembers.joinedAt,
          username: users.username,
        })
        .from(familyMembers)
        .leftJoin(users, eq(familyMembers.userId, users.id))
        .where(eq(familyMembers.groupId, groupId));
      return result.map((r: any) => ({
        id: r.id,
        groupId: r.groupId,
        userId: r.userId,
        role: r.role,
        joinedAt: r.joinedAt,
        username: r.username || "Неизвестный",
      }));
    } catch (error) {
      console.error("DB error in getGroupMembers:", error);
      return this.fallback.getGroupMembers(groupId);
    }
  }

  async createSharedList(groupId: string, name: string, listType: string): Promise<SharedList> {
    if (!this.useDb) return this.fallback.createSharedList(groupId, name, listType);
    try {
      const id = randomUUID();
      const newList = { id, groupId, name, listType };
      await this.db.insert(sharedLists).values(newList);
      const result = await this.db.select().from(sharedLists).where(eq(sharedLists.id, id));
      return result[0];
    } catch (error) {
      console.error("DB error in createSharedList:", error);
      return this.fallback.createSharedList(groupId, name, listType);
    }
  }

  async getSharedLists(groupId: string): Promise<SharedList[]> {
    if (!this.useDb) return this.fallback.getSharedLists(groupId);
    try {
      return this.db.select().from(sharedLists).where(eq(sharedLists.groupId, groupId));
    } catch (error) {
      return this.fallback.getSharedLists(groupId);
    }
  }

  async getSharedListItems(listId: string): Promise<SharedListItem[]> {
    if (!this.useDb) return this.fallback.getSharedListItems(listId);
    try {
      return this.db.select().from(sharedListItems).where(eq(sharedListItems.listId, listId));
    } catch (error) {
      return this.fallback.getSharedListItems(listId);
    }
  }

  async addSharedListItem(listId: string, text: string, userId: string): Promise<SharedListItem> {
    if (!this.useDb) return this.fallback.addSharedListItem(listId, text, userId);
    try {
      const id = randomUUID();
      const newItem = { id, listId, text, completed: false, createdBy: userId };
      await this.db.insert(sharedListItems).values(newItem);
      const result = await this.db.select().from(sharedListItems).where(eq(sharedListItems.id, id));
      return result[0];
    } catch (error) {
      console.error("DB error in addSharedListItem:", error);
      return this.fallback.addSharedListItem(listId, text, userId);
    }
  }

  async toggleSharedListItem(itemId: string): Promise<SharedListItem | undefined> {
    if (!this.useDb) return this.fallback.toggleSharedListItem(itemId);
    try {
      const existing = await this.db.select().from(sharedListItems).where(eq(sharedListItems.id, itemId));
      if (!existing[0]) return undefined;
      await this.db.update(sharedListItems).set({ completed: !existing[0].completed }).where(eq(sharedListItems.id, itemId));
      const result = await this.db.select().from(sharedListItems).where(eq(sharedListItems.id, itemId));
      return result[0];
    } catch (error) {
      return this.fallback.toggleSharedListItem(itemId);
    }
  }

  async deleteSharedListItem(itemId: string): Promise<boolean> {
    if (!this.useDb) return this.fallback.deleteSharedListItem(itemId);
    try {
      await this.db.delete(sharedListItems).where(eq(sharedListItems.id, itemId));
      return true;
    } catch (error) {
      return this.fallback.deleteSharedListItem(itemId);
    }
  }

  async getSharedListItem(itemId: string): Promise<SharedListItem | undefined> {
    if (!this.useDb) return this.fallback.getSharedListItem(itemId);
    try {
      const result = await this.db.select().from(sharedListItems).where(eq(sharedListItems.id, itemId));
      return result[0];
    } catch (error) {
      return this.fallback.getSharedListItem(itemId);
    }
  }

  async getSharedList(listId: string): Promise<SharedList | undefined> {
    if (!this.useDb) return this.fallback.getSharedList(listId);
    try {
      const result = await this.db.select().from(sharedLists).where(eq(sharedLists.id, listId));
      return result[0];
    } catch (error) {
      return this.fallback.getSharedList(listId);
    }
  }
}

export const storage = new DatabaseStorage();

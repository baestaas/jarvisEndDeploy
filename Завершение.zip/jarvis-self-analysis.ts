import OpenAI from "openai";
import { pool, isDatabaseConnected } from "./db";

// Используем OPENAI_API_KEY напрямую (системная переменная Manus)
let openai: OpenAI | null = null;
const analysisApiKey = process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
if (analysisApiKey) {
  try {
    openai = new OpenAI({
      apiKey: analysisApiKey,
    });
  } catch (e) {
    console.warn('[JarvisSelfAnalysis] OpenAI client not initialized:', e);
  }
}

interface ErrorLog {
  id: string;
  timestamp: Date;
  type: "frontend" | "backend" | "database" | "voice" | "api";
  severity: "low" | "medium" | "high" | "critical";
  message: string;
  stackTrace?: string;
  context?: Record<string, unknown>;
  resolved: boolean;
  resolution?: string;
}

interface HealthStatus {
  overall: "healthy" | "degraded" | "critical";
  components: {
    database: boolean;
    openai: boolean;
    webSearch: boolean;
    voiceSynthesis: boolean;
    memory: boolean;
  };
  lastCheck: Date;
  issues: string[];
  recommendations: string[];
}

interface AnalysisResult {
  diagnosis: string;
  rootCause: string;
  suggestedFix: string;
  autoFixable: boolean;
  priority: "low" | "medium" | "high" | "critical";
}

class JarvisSelfAnalysis {
  private errorLogs: ErrorLog[] = [];
  private healthStatus: HealthStatus;
  private lastHealthCheck: Date | null = null;
  private healthCheckInterval: NodeJS.Timeout | null = null;
  
  constructor() {
    this.healthStatus = {
      overall: "healthy",
      components: {
        database: false,
        openai: false,
        webSearch: false,
        voiceSynthesis: true,
        memory: false,
      },
      lastCheck: new Date(),
      issues: [],
      recommendations: [],
    };
    
    this.startHealthMonitoring();
  }
  
  private startHealthMonitoring() {
    // Ждём 10 секунд перед первой проверкой чтобы база успела инициализироваться
    setTimeout(() => {
      this.performHealthCheck();
    }, 10000);
    
    // Периодическая проверка каждые 5 минут
    this.healthCheckInterval = setInterval(() => {
      this.performHealthCheck();
    }, 5 * 60 * 1000);
  }
  
  async performHealthCheck(): Promise<HealthStatus> {
    console.log("[JarvisSelfAnalysis] Performing health check...");
    const issues: string[] = [];
    const recommendations: string[] = [];
    
    this.healthStatus.components.database = await this.checkDatabase();
    if (!this.healthStatus.components.database) {
      issues.push("Database connection unavailable");
      recommendations.push("Check PostgreSQL connection and credentials");
    }
    
    this.healthStatus.components.openai = await this.checkOpenAI();
    if (!this.healthStatus.components.openai) {
      issues.push("OpenAI API connection failed");
      recommendations.push("Verify AI_INTEGRATIONS_OPENAI_API_KEY is set correctly");
    }
    
    this.healthStatus.components.webSearch = await this.checkWebSearch();
    if (!this.healthStatus.components.webSearch) {
      issues.push("Web search service unavailable");
      recommendations.push("DuckDuckGo API may be rate-limited, will retry later");
    }
    
    this.healthStatus.components.memory = this.healthStatus.components.database;
    if (!this.healthStatus.components.memory) {
      issues.push("Memory system unavailable (requires database)");
      recommendations.push("Restore database connection to enable memory features");
    }
    
    const criticalCount = issues.filter(i => 
      i.includes("Database") || i.includes("OpenAI")
    ).length;
    
    if (criticalCount >= 2) {
      this.healthStatus.overall = "critical";
    } else if (issues.length > 0) {
      this.healthStatus.overall = "degraded";
    } else {
      this.healthStatus.overall = "healthy";
    }
    
    this.healthStatus.issues = issues;
    this.healthStatus.recommendations = recommendations;
    this.healthStatus.lastCheck = new Date();
    this.lastHealthCheck = new Date();
    
    console.log(`[JarvisSelfAnalysis] Health check complete: ${this.healthStatus.overall}`);
    if (issues.length > 0) {
      console.log(`[JarvisSelfAnalysis] Issues found: ${issues.join(", ")}`);
    }
    
    return this.healthStatus;
  }
  
  private async checkDatabase(): Promise<boolean> {
    try {
      if (!pool || !isDatabaseConnected()) {
        return false;
      }
      const result = await pool.query("SELECT 1 as test");
      return result.rows.length > 0;
    } catch (error) {
      console.error("[JarvisSelfAnalysis] Database check failed:", error);
      return false;
    }
  }
  
  private async checkOpenAI(): Promise<boolean> {
    try {
      const response = await openai.chat.completions.create({
        model: "gpt-4.1-mini",
        messages: [{ role: "user", content: "test" }],
        max_tokens: 5,
      });
      return !!response.choices[0]?.message?.content;
    } catch (error) {
      console.error("[JarvisSelfAnalysis] OpenAI check failed:", error);
      return false;
    }
  }
  
  private async checkWebSearch(): Promise<boolean> {
    try {
      const response = await fetch(
        "https://api.duckduckgo.com/?q=test&format=json&no_html=1",
        { signal: AbortSignal.timeout(5000) }
      );
      return response.ok;
    } catch (error) {
      console.error("[JarvisSelfAnalysis] Web search check failed:", error);
      return false;
    }
  }
  
  logError(
    type: ErrorLog["type"],
    severity: ErrorLog["severity"],
    message: string,
    stackTrace?: string,
    context?: Record<string, unknown>
  ): string {
    const errorId = `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const errorLog: ErrorLog = {
      id: errorId,
      timestamp: new Date(),
      type,
      severity,
      message,
      stackTrace,
      context,
      resolved: false,
    };
    
    this.errorLogs.push(errorLog);
    
    if (this.errorLogs.length > 100) {
      this.errorLogs = this.errorLogs.slice(-100);
    }
    
    console.log(`[JarvisSelfAnalysis] Error logged: ${errorId} - ${message}`);
    
    if (severity === "critical" || severity === "high") {
      this.analyzeAndAttemptFix(errorLog);
    }
    
    return errorId;
  }
  
  async analyzeError(errorId: string): Promise<AnalysisResult | null> {
    const error = this.errorLogs.find(e => e.id === errorId);
    if (!error) {
      return null;
    }
    
    try {
      const prompt = `Analyze this error and provide a diagnosis:

Error Type: ${error.type}
Severity: ${error.severity}
Message: ${error.message}
${error.stackTrace ? `Stack Trace: ${error.stackTrace}` : ""}
${error.context ? `Context: ${JSON.stringify(error.context)}` : ""}

Provide a JSON response with:
1. diagnosis: Brief description of the problem
2. rootCause: The likely root cause
3. suggestedFix: How to fix it
4. autoFixable: Whether this can be automatically fixed (true/false)
5. priority: low/medium/high/critical

Respond ONLY with valid JSON.`;

      const response = await openai.chat.completions.create({
        model: "gpt-4.1-mini",
        messages: [
          { role: "system", content: "You are a system diagnostics AI. Analyze errors and provide solutions in JSON format." },
          { role: "user", content: prompt }
        ],
        max_tokens: 500,
        temperature: 0.3,
      });
      
      const content = response.choices[0]?.message?.content || "";
      const jsonMatch = content.match(/\{[\s\S]*\}/);
      
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]) as AnalysisResult;
      }
      
      return {
        diagnosis: "Unable to parse analysis result",
        rootCause: "Unknown",
        suggestedFix: "Manual investigation required",
        autoFixable: false,
        priority: error.severity,
      };
    } catch (analysisError) {
      console.error("[JarvisSelfAnalysis] Error analysis failed:", analysisError);
      return null;
    }
  }
  
  private async analyzeAndAttemptFix(error: ErrorLog): Promise<void> {
    console.log(`[JarvisSelfAnalysis] Analyzing critical error: ${error.id}`);
    
    const analysis = await this.analyzeError(error.id);
    if (!analysis) {
      return;
    }
    
    console.log(`[JarvisSelfAnalysis] Diagnosis: ${analysis.diagnosis}`);
    console.log(`[JarvisSelfAnalysis] Root cause: ${analysis.rootCause}`);
    console.log(`[JarvisSelfAnalysis] Suggested fix: ${analysis.suggestedFix}`);
    
    if (analysis.autoFixable) {
      const fixed = await this.attemptAutoFix(error, analysis);
      if (fixed) {
        error.resolved = true;
        error.resolution = `Auto-fixed: ${analysis.suggestedFix}`;
        console.log(`[JarvisSelfAnalysis] Error auto-fixed: ${error.id}`);
      }
    }
  }
  
  private async attemptAutoFix(error: ErrorLog, analysis: AnalysisResult): Promise<boolean> {
    switch (error.type) {
      case "database":
        return await this.fixDatabaseIssue(error);
      case "api":
        return await this.fixApiIssue(error);
      case "voice":
        return await this.fixVoiceIssue(error);
      default:
        console.log(`[JarvisSelfAnalysis] No auto-fix available for type: ${error.type}`);
        return false;
    }
  }
  
  private async fixDatabaseIssue(error: ErrorLog): Promise<boolean> {
    console.log("[JarvisSelfAnalysis] Attempting database fix...");
    
    if (error.message.includes("connection") || error.message.includes("ECONNREFUSED")) {
      try {
        if (pool) {
          await pool.end();
          await new Promise(resolve => setTimeout(resolve, 1000));
          await pool.connect();
          const result = await pool.query("SELECT 1 as test");
          if (result.rows.length > 0) {
            console.log("[JarvisSelfAnalysis] Database reconnected successfully");
            return true;
          }
        }
      } catch (reconnectError) {
        console.log("[JarvisSelfAnalysis] Database reconnection failed:", reconnectError);
      }
    }
    
    if (error.message.includes("timeout")) {
      console.log("[JarvisSelfAnalysis] Database timeout - clearing query queue");
      return false;
    }
    
    return false;
  }
  
  private async fixApiIssue(error: ErrorLog): Promise<boolean> {
    console.log("[JarvisSelfAnalysis] Attempting API fix...");
    
    if (error.message.includes("rate limit") || error.message.includes("429")) {
      const waitTime = 5000;
      console.log(`[JarvisSelfAnalysis] Rate limit detected, waiting ${waitTime}ms before retry`);
      await new Promise(resolve => setTimeout(resolve, waitTime));
      
      try {
        const testResponse = await openai.chat.completions.create({
          model: "gpt-4.1-mini",
          messages: [{ role: "user", content: "test" }],
          max_tokens: 5,
        });
        if (testResponse.choices[0]?.message?.content) {
          console.log("[JarvisSelfAnalysis] API connection restored after backoff");
          return true;
        }
      } catch {
        console.log("[JarvisSelfAnalysis] API still rate limited");
      }
    }
    
    if (error.message.includes("timeout")) {
      console.log("[JarvisSelfAnalysis] API timeout - will retry with longer timeout");
      return false;
    }
    
    return false;
  }
  
  private async fixVoiceIssue(error: ErrorLog): Promise<boolean> {
    console.log("[JarvisSelfAnalysis] Voice issues are client-side, logging for monitoring");
    return false;
  }
  
  getHealthStatus(): HealthStatus {
    return this.healthStatus;
  }
  
  getRecentErrors(count: number = 10): ErrorLog[] {
    return this.errorLogs.slice(-count);
  }
  
  getUnresolvedErrors(): ErrorLog[] {
    return this.errorLogs.filter(e => !e.resolved);
  }
  
  async generateStatusReport(): Promise<string> {
    const status = this.healthStatus;
    const unresolvedErrors = this.getUnresolvedErrors();
    
    let report = `Отчёт о состоянии системы, сэр.\n\n`;
    report += `Общий статус: ${status.overall === "healthy" ? "Все системы работают нормально" : 
               status.overall === "degraded" ? "Некоторые системы работают с ограничениями" : 
               "Обнаружены критические проблемы"}\n\n`;
    
    report += `Компоненты:\n`;
    report += `- База данных: ${status.components.database ? "В норме" : "Недоступна"}\n`;
    report += `- Искусственный интеллект: ${status.components.openai ? "В норме" : "Недоступен"}\n`;
    report += `- Веб-поиск: ${status.components.webSearch ? "В норме" : "Недоступен"}\n`;
    report += `- Система памяти: ${status.components.memory ? "В норме" : "Недоступна"}\n`;
    
    if (unresolvedErrors.length > 0) {
      report += `\nНерешённых ошибок: ${unresolvedErrors.length}\n`;
      const criticalCount = unresolvedErrors.filter(e => e.severity === "critical").length;
      if (criticalCount > 0) {
        report += `Из них критических: ${criticalCount}\n`;
      }
    }
    
    if (status.recommendations.length > 0) {
      report += `\nРекомендации:\n`;
      status.recommendations.forEach((rec, i) => {
        report += `${i + 1}. ${rec}\n`;
      });
    }
    
    return report;
  }
  
  stopMonitoring() {
    if (this.healthCheckInterval) {
      clearInterval(this.healthCheckInterval);
      this.healthCheckInterval = null;
    }
  }
}

export const jarvisSelfAnalysis = new JarvisSelfAnalysis();

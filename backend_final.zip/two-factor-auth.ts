import * as OTPAuth from "otpauth";
import QRCode from "qrcode";
import { randomBytes } from "crypto";

const ISSUER = "JarVoice";

export function generateTotpSecret(): string {
  const secret = new OTPAuth.Secret({ size: 20 });
  return secret.base32;
}

export async function generateQRCode(secret: string, username: string): Promise<string> {
  const totp = new OTPAuth.TOTP({
    issuer: ISSUER,
    label: username,
    algorithm: "SHA1",
    digits: 6,
    period: 30,
    secret: OTPAuth.Secret.fromBase32(secret),
  });

  const uri = totp.toString();
  const qrCodeDataUrl = await QRCode.toDataURL(uri, {
    width: 256,
    margin: 2,
    color: {
      dark: "#00d4ff",
      light: "#0a0a1a",
    },
  });

  return qrCodeDataUrl;
}

export function verifyTotpCode(secret: string, code: string): boolean {
  const totp = new OTPAuth.TOTP({
    issuer: ISSUER,
    algorithm: "SHA1",
    digits: 6,
    period: 30,
    secret: OTPAuth.Secret.fromBase32(secret),
  });

  const delta = totp.validate({ token: code, window: 1 });
  return delta !== null;
}

export function generateBackupCodes(count: number = 8): string[] {
  const codes: string[] = [];
  for (let i = 0; i < count; i++) {
    const code = randomBytes(4).toString("hex").toUpperCase();
    const formatted = code.slice(0, 4) + "-" + code.slice(4);
    codes.push(formatted);
  }
  return codes;
}

export function verifyBackupCode(codes: string[], code: string): { valid: boolean; remainingCodes: string[] } {
  const normalizedCode = code.toUpperCase().replace(/\s/g, "");
  const index = codes.findIndex(c => c.replace(/-/g, "") === normalizedCode.replace(/-/g, ""));
  
  if (index === -1) {
    return { valid: false, remainingCodes: codes };
  }

  const remainingCodes = [...codes];
  remainingCodes.splice(index, 1);
  return { valid: true, remainingCodes };
}

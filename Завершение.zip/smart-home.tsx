import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { 
  Home, Sofa, Bed, ChefHat, Bath, Monitor,
  DoorOpen, Moon, Film, Sun,
  Lightbulb, Thermometer, Power, Minus, Plus, 
  Snowflake, Plug, Droplets, Wifi, WifiOff
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { cn } from "@/lib/utils";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type DeviceType = "light" | "ac" | "outlet" | "sensor";

interface Device {
  id: string;
  name: string;
  type: DeviceType;
  roomId: string;
  isOn: boolean;
  brightness?: number;
  temperature?: number;
  targetTemperature?: number;
  humidity?: number;
  sensorTemperature?: number;
  sensorHumidity?: number;
  online: boolean;
}

interface Room {
  id: string;
  name: string;
  icon: string;
  devices: string[];
}

interface Scene {
  id: string;
  name: string;
  icon: string;
  description: string;
}

const iconMap: Record<string, typeof Home> = {
  Sofa, Bed, ChefHat, Bath, Monitor,
  DoorOpen, Moon, Film, Sun,
};

const getRoomIcon = (iconName: string) => iconMap[iconName] || Home;
const getSceneIcon = (iconName: string) => iconMap[iconName] || Home;

const getDeviceIcon = (type: DeviceType) => {
  switch (type) {
    case "light": return Lightbulb;
    case "ac": return Snowflake;
    case "outlet": return Plug;
    case "sensor": return Thermometer;
  }
};

export function SmartHomePage() {
  const { toast } = useToast();
  const [activeRoom, setActiveRoom] = useState<string>("all");
  const [activeScene, setActiveScene] = useState<string | null>(null);

  const { data: stateData, isLoading } = useQuery<{
    success: boolean;
    devices: Device[];
    rooms: Room[];
    scenes: Scene[];
  }>({
    queryKey: ["/api/smart-home/state"],
  });

  const deviceMutation = useMutation({
    mutationFn: async ({ id, state }: { id: string; state: Partial<Device> }) => {
      return apiRequest(`/api/smart-home/device/${id}`, {
        method: "POST",
        body: JSON.stringify(state),
        headers: { "Content-Type": "application/json" },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/smart-home/state"] });
    },
  });

  const sceneMutation = useMutation({
    mutationFn: async (sceneId: string) => {
      return apiRequest(`/api/smart-home/scene/${sceneId}/activate`, {
        method: "POST",
      });
    },
    onSuccess: (_, sceneId) => {
      setActiveScene(sceneId);
      queryClient.invalidateQueries({ queryKey: ["/api/smart-home/state"] });
      toast({
        title: "Сценарий активирован",
        description: "Настройки умного дома обновлены",
      });
    },
  });

  const devices = stateData?.devices || [];
  const rooms = stateData?.rooms || [];
  const scenes = stateData?.scenes || [];

  const filteredDevices = activeRoom === "all" 
    ? devices 
    : devices.filter(d => d.roomId === activeRoom);

  const activeDevicesCount = devices.filter(d => d.isOn && d.type !== "sensor").length;
  const totalDevicesCount = devices.filter(d => d.type !== "sensor").length;

  const sensors = devices.filter(d => d.type === "sensor");
  const avgTemperature = sensors.length > 0 
    ? (sensors.reduce((sum, s) => sum + (s.sensorTemperature || 0), 0) / sensors.length).toFixed(1)
    : "--";
  const avgHumidity = sensors.length > 0
    ? Math.round(sensors.reduce((sum, s) => sum + (s.sensorHumidity || 0), 0) / sensors.length)
    : "--";

  const toggleDevice = (device: Device) => {
    deviceMutation.mutate({ 
      id: device.id, 
      state: { isOn: !device.isOn } 
    });
  };

  const updateBrightness = (device: Device, brightness: number) => {
    deviceMutation.mutate({ 
      id: device.id, 
      state: { brightness } 
    });
  };

  const updateTemperature = (device: Device, delta: number) => {
    const newTemp = Math.max(16, Math.min(30, (device.temperature || 23) + delta));
    deviceMutation.mutate({ 
      id: device.id, 
      state: { temperature: newTemp } 
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-12 h-12 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Загрузка умного дома...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-24">
      <div>
        <h1 className="font-display text-2xl text-primary" data-testid="text-smarthome-title">
          Умный дом
        </h1>
        <p className="text-muted-foreground text-sm">Управление устройствами и сценариями</p>
      </div>

      <Card className="card-cyber border-primary/30 bg-primary/5">
        <CardContent className="py-3 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
            <Home className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="text-primary font-medium text-sm">Эмуляция</p>
            <p className="text-muted-foreground text-xs">Виртуальные устройства для демонстрации возможностей</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-3 gap-3">
        <Card className="card-cyber">
          <CardContent className="pt-4 text-center">
            <div className="text-2xl font-bold text-primary" data-testid="text-active-devices">
              {activeDevicesCount}/{totalDevicesCount}
            </div>
            <div className="text-xs text-muted-foreground">Устройств вкл.</div>
          </CardContent>
        </Card>
        <Card className="card-cyber">
          <CardContent className="pt-4 text-center">
            <div className="flex items-center justify-center gap-1">
              <Thermometer className="w-4 h-4 text-orange-400" />
              <span className="text-2xl font-bold text-primary" data-testid="text-avg-temp">
                {avgTemperature}°
              </span>
            </div>
            <div className="text-xs text-muted-foreground">Средняя t°</div>
          </CardContent>
        </Card>
        <Card className="card-cyber">
          <CardContent className="pt-4 text-center">
            <div className="flex items-center justify-center gap-1">
              <Droplets className="w-4 h-4 text-blue-400" />
              <span className="text-2xl font-bold text-primary" data-testid="text-avg-humidity">
                {avgHumidity}%
              </span>
            </div>
            <div className="text-xs text-muted-foreground">Влажность</div>
          </CardContent>
        </Card>
      </div>

      <Card className="card-cyber">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Power className="w-4 h-4 text-primary" />
            Сценарии
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-2">
            {scenes.map((scene) => {
              const Icon = getSceneIcon(scene.icon);
              const isActive = activeScene === scene.id;
              
              return (
                <Button
                  key={scene.id}
                  variant={isActive ? "default" : "outline"}
                  className={cn(
                    "flex-col h-auto py-3 gap-1",
                    isActive && "bg-gradient-to-r from-cyan-500 to-purple-600"
                  )}
                  onClick={() => sceneMutation.mutate(scene.id)}
                  disabled={sceneMutation.isPending}
                  data-testid={`button-scene-${scene.id}`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs">{scene.name}</span>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeRoom} onValueChange={setActiveRoom}>
        <TabsList className="w-full flex overflow-x-auto gap-1 bg-transparent p-0">
          <TabsTrigger 
            value="all" 
            className="flex-shrink-0 data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500 data-[state=active]:to-purple-600"
            data-testid="tab-room-all"
          >
            <Home className="w-4 h-4 mr-1" />
            Все
          </TabsTrigger>
          {rooms.map((room) => {
            const Icon = getRoomIcon(room.icon);
            return (
              <TabsTrigger 
                key={room.id} 
                value={room.id}
                className="flex-shrink-0 data-[state=active]:bg-gradient-to-r data-[state=active]:from-cyan-500 data-[state=active]:to-purple-600"
                data-testid={`tab-room-${room.id}`}
              >
                <Icon className="w-4 h-4 mr-1" />
                {room.name}
              </TabsTrigger>
            );
          })}
        </TabsList>

        <TabsContent value={activeRoom} className="mt-4 space-y-3">
          {filteredDevices.length === 0 ? (
            <Card className="card-cyber">
              <CardContent className="py-8 text-center text-muted-foreground">
                Нет устройств в этой комнате
              </CardContent>
            </Card>
          ) : (
            filteredDevices.map((device) => (
              <DeviceCard 
                key={device.id}
                device={device}
                room={rooms.find(r => r.id === device.roomId)}
                onToggle={() => toggleDevice(device)}
                onBrightnessChange={(val) => updateBrightness(device, val)}
                onTemperatureChange={(delta) => updateTemperature(device, delta)}
                isUpdating={deviceMutation.isPending}
              />
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface DeviceCardProps {
  device: Device;
  room?: Room;
  onToggle: () => void;
  onBrightnessChange: (val: number) => void;
  onTemperatureChange: (delta: number) => void;
  isUpdating: boolean;
}

function DeviceCard({ 
  device, 
  room, 
  onToggle, 
  onBrightnessChange,
  onTemperatureChange,
  isUpdating 
}: DeviceCardProps) {
  const Icon = getDeviceIcon(device.type);
  const isSensor = device.type === "sensor";

  return (
    <Card 
      className={cn(
        "card-cyber transition-all duration-300",
        device.isOn && !isSensor && "ring-1 ring-primary/30"
      )} 
      data-testid={`card-device-${device.id}`}
    >
      <CardContent className="py-4">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-1">
            <div className={cn(
              "w-10 h-10 rounded-full flex items-center justify-center transition-all duration-300",
              device.isOn 
                ? "bg-gradient-to-r from-cyan-500 to-purple-600 shadow-lg shadow-cyan-500/30" 
                : "bg-muted"
            )}>
              <Icon className={cn(
                "w-5 h-5",
                device.isOn ? "text-white" : "text-muted-foreground"
              )} />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm truncate">{device.name}</div>
              <div className="flex items-center gap-2 flex-wrap">
                {room && (
                  <span className="text-xs text-muted-foreground">{room.name}</span>
                )}
                {device.online ? (
                  <Wifi className="w-3 h-3 text-green-400" />
                ) : (
                  <WifiOff className="w-3 h-3 text-red-400" />
                )}
                {device.type === "ac" && device.isOn && (
                  <Badge variant="outline" className="text-xs">
                    {device.temperature}°C
                  </Badge>
                )}
                {device.type === "light" && device.isOn && device.brightness !== undefined && (
                  <Badge variant="outline" className="text-xs">
                    {device.brightness}%
                  </Badge>
                )}
              </div>
            </div>
          </div>
          
          {!isSensor && (
            <Button
              size="icon"
              variant={device.isOn ? "default" : "outline"}
              className={cn(
                device.isOn && "bg-gradient-to-r from-cyan-500 to-purple-600"
              )}
              onClick={onToggle}
              disabled={isUpdating}
              data-testid={`button-toggle-${device.id}`}
            >
              <Power className="w-4 h-4" />
            </Button>
          )}
        </div>

        {device.type === "light" && device.isOn && device.brightness !== undefined && (
          <div className="mt-4 flex items-center gap-3">
            <Lightbulb className="w-4 h-4 text-yellow-400" />
            <Slider
              value={[device.brightness]}
              min={1}
              max={100}
              step={1}
              onValueChange={([val]) => onBrightnessChange(val)}
              className="flex-1"
              disabled={isUpdating}
              data-testid={`slider-brightness-${device.id}`}
            />
            <span className="text-xs text-muted-foreground w-8 text-right">
              {device.brightness}%
            </span>
          </div>
        )}

        {device.type === "ac" && device.isOn && (
          <div className="mt-4 flex items-center justify-center gap-4">
            <Button
              size="icon"
              variant="outline"
              onClick={() => onTemperatureChange(-1)}
              disabled={isUpdating || (device.temperature || 23) <= 16}
              data-testid={`button-temp-down-${device.id}`}
            >
              <Minus className="w-4 h-4" />
            </Button>
            <div className="flex items-center gap-2">
              <Snowflake className="w-5 h-5 text-blue-400" />
              <span className="text-2xl font-bold text-primary">
                {device.temperature}°C
              </span>
            </div>
            <Button
              size="icon"
              variant="outline"
              onClick={() => onTemperatureChange(1)}
              disabled={isUpdating || (device.temperature || 23) >= 30}
              data-testid={`button-temp-up-${device.id}`}
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
        )}

        {device.type === "sensor" && (
          <div className="mt-4 grid grid-cols-2 gap-4">
            <div className="flex items-center gap-2 bg-muted/50 rounded-lg p-3">
              <Thermometer className="w-5 h-5 text-orange-400" />
              <div>
                <div className="text-lg font-bold text-primary">
                  {device.sensorTemperature?.toFixed(1)}°C
                </div>
                <div className="text-xs text-muted-foreground">Температура</div>
              </div>
            </div>
            <div className="flex items-center gap-2 bg-muted/50 rounded-lg p-3">
              <Droplets className="w-5 h-5 text-blue-400" />
              <div>
                <div className="text-lg font-bold text-primary">
                  {device.sensorHumidity}%
                </div>
                <div className="text-xs text-muted-foreground">Влажность</div>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

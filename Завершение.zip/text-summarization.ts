import OpenAI from "openai";

// Используем OPENAI_API_KEY напрямую (системная переменная Manus)
let openai: OpenAI | null = null;
const summaryApiKey = process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
if (summaryApiKey) {
  try {
    openai = new OpenAI({
      apiKey: summaryApiKey,
    });
  } catch (e) {
    console.warn('[TextSummarization] OpenAI client not initialized:', e);
  }
}

const SUMMARIZATION_PATTERNS = [
  /суммаризуй/i,
  /краткое содержание/i,
  /резюмируй/i,
  /подведи итог/i,
  /о чём эта статья/i,
  /о чем эта статья/i,
  /расскажи кратко/i,
  /кратко о/i,
  /сократи текст/i,
  /что в статье/i,
  /summarize/i,
  /summary/i,
];

const URL_PATTERN = /https?:\/\/[^\s]+/gi;

export function isSummarizationRequest(text: string): boolean {
  const lowerText = text.toLowerCase();
  return SUMMARIZATION_PATTERNS.some(pattern => pattern.test(lowerText));
}

export function extractSummarizationContent(text: string): { type: 'url' | 'text'; content: string } | null {
  const urlMatch = text.match(URL_PATTERN);
  
  if (urlMatch && urlMatch.length > 0) {
    return { type: 'url', content: urlMatch[0] };
  }
  
  let cleanedText = text;
  for (const pattern of SUMMARIZATION_PATTERNS) {
    cleanedText = cleanedText.replace(pattern, '');
  }
  
  cleanedText = cleanedText.replace(/[:：]/g, '').trim();
  
  if (cleanedText.length > 50) {
    return { type: 'text', content: cleanedText };
  }
  
  return null;
}

export async function fetchUrlContent(url: string): Promise<string> {
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; JarVoice/1.0; +https://jarvoice.app)',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'ru-RU,ru;q=0.9,en;q=0.8',
      },
      signal: AbortSignal.timeout(15000),
    });
    
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    
    const html = await response.text();
    
    const textContent = extractTextFromHtml(html);
    
    return textContent.substring(0, 15000);
  } catch (error) {
    console.error('Error fetching URL:', error);
    throw new Error(`Не удалось загрузить содержимое по ссылке: ${(error as Error).message}`);
  }
}

function extractTextFromHtml(html: string): string {
  let text = html
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<nav[^>]*>[\s\S]*?<\/nav>/gi, '')
    .replace(/<header[^>]*>[\s\S]*?<\/header>/gi, '')
    .replace(/<footer[^>]*>[\s\S]*?<\/footer>/gi, '')
    .replace(/<aside[^>]*>[\s\S]*?<\/aside>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  
  text = text
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/p>/gi, '\n\n')
    .replace(/<\/div>/gi, '\n')
    .replace(/<\/h[1-6]>/gi, '\n\n')
    .replace(/<\/li>/gi, '\n')
    .replace(/<[^>]+>/g, ' ');
  
  text = text
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#\d+;/g, '')
    .replace(/&\w+;/g, '');
  
  text = text
    .replace(/\s+/g, ' ')
    .replace(/\n\s*\n/g, '\n\n')
    .trim();
  
  return text;
}

export async function summarizeText(
  text: string,
  style: 'brief' | 'detailed' = 'brief'
): Promise<string> {
  if (!text || text.trim().length < 50) {
    throw new Error('Текст слишком короткий для суммаризации');
  }
  
  const systemPrompt = style === 'brief'
    ? `Ты — Джарвис, персональный ИИ-ассистент. Сделай краткое резюме текста в 2-4 предложениях. 
Говори в стиле Джарвиса: вежливо, профессионально, с обращением "сэр". 
Начни с фразы вроде "Позвольте изложить суть, сэр." или "Краткое содержание, сэр:"`
    : `Ты — Джарвис, персональный ИИ-ассистент. Сделай подробное резюме текста, выделив ключевые моменты.
Говори в стиле Джарвиса: вежливо, профессионально, с обращением "сэр".
Начни с фразы вроде "Позвольте представить детальный анализ, сэр." и структурируй информацию.`;

  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4.1-mini",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Резюмируй следующий текст:\n\n${text.substring(0, 12000)}` }
      ],
      max_tokens: style === 'brief' ? 300 : 600,
      temperature: 0.7,
    });

    return completion.choices[0]?.message?.content || 
      "Прошу прощения, сэр, но мне не удалось обработать этот текст.";
  } catch (error) {
    console.error('Summarization error:', error);
    throw new Error(`Ошибка суммаризации: ${(error as Error).message}`);
  }
}

export async function summarizeUrl(
  url: string,
  style: 'brief' | 'detailed' = 'brief'
): Promise<string> {
  const content = await fetchUrlContent(url);
  
  if (!content || content.length < 100) {
    throw new Error('Не удалось извлечь достаточно текста со страницы');
  }
  
  return summarizeText(content, style);
}

export async function processSummarizationCommand(
  command: string,
  style: 'brief' | 'detailed' = 'brief'
): Promise<string> {
  const extracted = extractSummarizationContent(command);
  
  if (!extracted) {
    return "Сэр, для суммаризации мне необходим либо URL статьи, либо текст длиной более 50 символов. Пожалуйста, уточните запрос.";
  }
  
  try {
    if (extracted.type === 'url') {
      return await summarizeUrl(extracted.content, style);
    } else {
      return await summarizeText(extracted.content, style);
    }
  } catch (error) {
    return `Прошу прощения, сэр. ${(error as Error).message}`;
  }
}

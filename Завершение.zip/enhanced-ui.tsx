/**
 * Enhanced UI Components for Market-Leading Experience
 * Улучшенные компоненты UI для премиум опыта
 */

import React from "react";
import { cn } from "@/lib/utils";

// ============================================
// 1. PREMIUM CARD COMPONENT
// ============================================
interface PremiumCardProps {
  children: React.ReactNode;
  className?: string;
  hover?: boolean;
  gradient?: "blue" | "purple" | "cyan" | "success";
}

export function PremiumCard({
  children,
  className,
  hover = true,
  gradient = "blue",
}: PremiumCardProps) {
  const gradients = {
    blue: "from-blue-500/20 to-cyan-500/20",
    purple: "from-purple-500/20 to-pink-500/20",
    cyan: "from-cyan-500/20 to-blue-500/20",
    success: "from-green-500/20 to-emerald-500/20",
  };

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-xl border border-white/10 backdrop-blur-xl",
        `bg-gradient-to-br ${gradients[gradient]}`,
        hover && "transition-all duration-300 hover:border-white/20 hover:shadow-lg hover:shadow-primary/20",
        className
      )}
    >
      {/* Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
      
      {/* Content */}
      <div className="relative z-10">{children}</div>
    </div>
  );
}

// ============================================
// 2. ANIMATED BUTTON COMPONENT
// ============================================
interface AnimatedButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "success" | "danger";
  size?: "sm" | "md" | "lg";
  loading?: boolean;
  icon?: React.ReactNode;
}

export function AnimatedButton({
  variant = "primary",
  size = "md",
  loading = false,
  icon,
  children,
  className,
  disabled,
  ...props
}: AnimatedButtonProps) {
  const variants = {
    primary: "bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600",
    secondary: "bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600",
    success: "bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600",
    danger: "bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600",
  };

  const sizes = {
    sm: "px-3 py-1.5 text-sm",
    md: "px-4 py-2 text-base",
    lg: "px-6 py-3 text-lg",
  };

  return (
    <button
      className={cn(
        "relative inline-flex items-center justify-center gap-2 font-semibold text-white rounded-lg",
        "transition-all duration-200 transform hover:scale-105 active:scale-95",
        "disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100",
        variants[variant],
        sizes[size],
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {loading && (
        <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-white/20 to-transparent animate-pulse" />
      )}
      {icon && <span className="flex-shrink-0">{icon}</span>}
      <span className="relative z-10">{children}</span>
    </button>
  );
}

// ============================================
// 3. GLOWING TEXT COMPONENT
// ============================================
interface GlowingTextProps {
  children: React.ReactNode;
  color?: "blue" | "cyan" | "purple" | "success";
  className?: string;
}

export function GlowingText({
  children,
  color = "cyan",
  className,
}: GlowingTextProps) {
  const colors = {
    blue: "text-blue-400 drop-shadow-[0_0_8px_rgba(59,130,246,0.5)]",
    cyan: "text-cyan-400 drop-shadow-[0_0_8px_rgba(34,211,238,0.5)]",
    purple: "text-purple-400 drop-shadow-[0_0_8px_rgba(168,85,247,0.5)]",
    success: "text-green-400 drop-shadow-[0_0_8px_rgba(74,222,128,0.5)]",
  };

  return (
    <span className={cn("font-semibold", colors[color], className)}>
      {children}
    </span>
  );
}

// ============================================
// 4. ANIMATED PROGRESS BAR
// ============================================
interface AnimatedProgressProps {
  value: number;
  max?: number;
  color?: "blue" | "purple" | "success";
  showLabel?: boolean;
}

export function AnimatedProgress({
  value,
  max = 100,
  color = "blue",
  showLabel = true,
}: AnimatedProgressProps) {
  const percentage = (value / max) * 100;
  const colors = {
    blue: "from-blue-500 to-cyan-500",
    purple: "from-purple-500 to-pink-500",
    success: "from-green-500 to-emerald-500",
  };

  return (
    <div className="w-full">
      <div className="h-2 bg-white/10 rounded-full overflow-hidden">
        <div
          className={cn(
            "h-full bg-gradient-to-r transition-all duration-500 ease-out",
            colors[color]
          )}
          style={{ width: `${percentage}%` }}
        />
      </div>
      {showLabel && (
        <div className="text-xs text-muted-foreground mt-1 text-right">
          {Math.round(percentage)}%
        </div>
      )}
    </div>
  );
}

// ============================================
// 5. FLOATING LABEL INPUT
// ============================================
interface FloatingLabelInputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  icon?: React.ReactNode;
}

export function FloatingLabelInput({
  label,
  icon,
  className,
  ...props
}: FloatingLabelInputProps) {
  const [isFocused, setIsFocused] = React.useState(false);
  const [hasValue, setHasValue] = React.useState(!!props.value);

  return (
    <div className="relative">
      <div className="relative">
        {icon && (
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">
            {icon}
          </div>
        )}
        <input
          {...props}
          className={cn(
            "w-full px-4 py-3 bg-white/5 border border-white/10 rounded-lg",
            "focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20",
            "transition-all duration-200",
            icon && "pl-10",
            className
          )}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setIsFocused(false)}
          onChange={(e) => setHasValue(!!e.target.value)}
        />
      </div>
      <label
        className={cn(
          "absolute left-4 transition-all duration-200 pointer-events-none",
          icon && "left-10",
          isFocused || hasValue
            ? "top-0 text-xs text-primary -translate-y-1/2 bg-black px-1"
            : "top-1/2 -translate-y-1/2 text-muted-foreground"
        )}
      >
        {label}
      </label>
    </div>
  );
}

// ============================================
// 6. NOTIFICATION BADGE
// ============================================
interface NotificationBadgeProps {
  count: number;
  color?: "red" | "blue" | "yellow";
  className?: string;
}

export function NotificationBadge({
  count,
  color = "red",
  className,
}: NotificationBadgeProps) {
  const colors = {
    red: "bg-red-500",
    blue: "bg-blue-500",
    yellow: "bg-yellow-500",
  };

  if (count === 0) return null;

  return (
    <div
      className={cn(
        "absolute -top-2 -right-2 w-6 h-6 rounded-full flex items-center justify-center",
        "text-xs font-bold text-white animate-pulse",
        colors[color],
        className
      )}
    >
      {count > 99 ? "99+" : count}
    </div>
  );
}

// ============================================
// 7. SKELETON LOADER
// ============================================
interface SkeletonProps {
  className?: string;
  count?: number;
}

export function Skeleton({ className, count = 1 }: SkeletonProps) {
  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className={cn(
            "bg-gradient-to-r from-white/10 to-white/5 rounded-lg",
            "animate-pulse",
            className
          )}
        />
      ))}
    </>
  );
}

// ============================================
// 8. TOOLTIP COMPONENT
// ============================================
interface TooltipProps {
  children: React.ReactNode;
  content: string;
  position?: "top" | "bottom" | "left" | "right";
}

export function Tooltip({
  children,
  content,
  position = "top",
}: TooltipProps) {
  const positions = {
    top: "bottom-full mb-2",
    bottom: "top-full mt-2",
    left: "right-full mr-2",
    right: "left-full ml-2",
  };

  return (
    <div className="group relative inline-block">
      {children}
      <div
        className={cn(
          "absolute hidden group-hover:block bg-black/80 text-white text-xs rounded px-2 py-1 whitespace-nowrap",
          "z-50 pointer-events-none",
          positions[position]
        )}
      >
        {content}
      </div>
    </div>
  );
}

// ============================================
// 9. MODAL OVERLAY
// ============================================
interface ModalOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  children: React.ReactNode;
  title?: string;
}

export function ModalOverlay({
  isOpen,
  onClose,
  children,
  title,
}: ModalOverlayProps) {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center"
      onClick={onClose}
    >
      <div
        className="bg-black/80 border border-white/10 rounded-xl p-6 max-w-md w-full mx-4"
        onClick={(e) => e.stopPropagation()}
      >
        {title && <h2 className="text-xl font-bold mb-4">{title}</h2>}
        {children}
      </div>
    </div>
  );
}

// ============================================
// 10. ANIMATED COUNTER
// ============================================
interface AnimatedCounterProps {
  value: number;
  suffix?: string;
  duration?: number;
}

export function AnimatedCounter({
  value,
  suffix = "",
  duration = 1000,
}: AnimatedCounterProps) {
  const [displayValue, setDisplayValue] = React.useState(0);

  React.useEffect(() => {
    let startTime: number;
    let animationId: number;

    const animate = (currentTime: number) => {
      if (!startTime) startTime = currentTime;
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);

      setDisplayValue(Math.floor(value * progress));

      if (progress < 1) {
        animationId = requestAnimationFrame(animate);
      }
    };

    animationId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animationId);
  }, [value, duration]);

  return (
    <span>
      {displayValue}
      {suffix}
    </span>
  );
}

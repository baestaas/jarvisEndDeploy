    <div className="min-h-screen flex flex-col justify-center p-6">
      <div className="text-center mb-10">
        <h1 className="font-display text-5xl font-black text-gradient tracking-wider" data-testid="text-auth-logo">
          JARVOICE
        </h1>
        <p className="text-muted-foreground mt-2">Персональный ассистент Джарвис</p>
      </div>

      <Card className="card-cyber max-w-md mx-auto w-full">
        <CardHeader>
          <CardTitle className="font-display text-xl text-primary text-center">
            {isLogin ? "Вход в систему" : "Регистрация"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Имя пользователя</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="jarvis_user"
                className="bg-muted border-primary/20"
                required
                data-testid="input-username"
              />
            </div>

            {!isLogin && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
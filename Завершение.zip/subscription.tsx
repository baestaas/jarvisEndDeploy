import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { ArrowLeft, Crown, Check, Loader2, Star, Zap, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface SubscriptionPageProps {
  onNavigate: (section: string) => void;
}

interface Plan {
  id: string;
  name: string;
  description: string;
  price: number;
  priceId?: string;
  features: string[];
  popular?: boolean;
  current?: boolean;
}

const defaultPlans: Plan[] = [
  {
    id: "basic",
    name: "Базовый",
    description: "Для начала работы с JarVoice",
    price: 0,
    features: [
      "Голосовой ассистент",
      "Напоминания",
      "Погода",
      "Базовые функции"
    ]
  },
  {
    id: "pro",
    name: "Про",
    description: "Для продвинутых пользователей",
    price: 299,
    features: [
      "Всё из Базового",
      "Умный дом",
      "Финансы",
      "Календарь с синхронизацией",
      "Генерация изображений",
      "Приоритетная поддержка"
    ],
    popular: true
  },
  {
    id: "premium",
    name: "Премиум",
    description: "Максимальные возможности",
    price: 599,
    features: [
      "Всё из Про",
      "Неограниченные запросы AI",
      "IDE разработка",
      "API доступ",
      "Приоритетные обновления",
      "Персональная настройка"
    ]
  }
];

export function SubscriptionPage({ onNavigate }: SubscriptionPageProps) {
  const { toast } = useToast();
  const [loadingPriceId, setLoadingPriceId] = useState<string | null>(null);

  const { data: subscriptionData, isLoading: subscriptionLoading } = useQuery({
    queryKey: ["/api/subscription"],
  });

  const { data: productsData } = useQuery({
    queryKey: ["/api/stripe/products"],
  });

  const checkoutMutation = useMutation({
    mutationFn: async (priceId: string) => {
      const response = await apiRequest("POST", "/api/stripe/checkout", { priceId });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success && data.url) {
        window.location.href = data.url;
      } else {
        toast({
          variant: "destructive",
          title: "Ошибка",
          description: data.error || "Не удалось создать сессию оплаты",
        });
      }
      setLoadingPriceId(null);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Не удалось подключиться к платёжной системе",
      });
      setLoadingPriceId(null);
    },
  });

  const portalMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/stripe/portal", {});
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success && data.url) {
        window.location.href = data.url;
      } else {
        toast({
          variant: "destructive",
          title: "Ошибка",
          description: data.error || "Не удалось открыть портал",
        });
      }
    },
  });

  const currentPlan = (subscriptionData as any)?.plan || "basic";
  const hasActiveSubscription = currentPlan !== "basic";

  const plans = defaultPlans.map(plan => ({
    ...plan,
    current: plan.id === currentPlan
  }));

  const getStripeProducts = () => {
    const products = (productsData as any)?.products || [];
    return products;
  };

  const handleSubscribe = (plan: Plan) => {
    if (plan.price === 0) return;
    
    const stripeProducts = getStripeProducts();
    const matchingProduct = stripeProducts.find((p: any) => 
      p.name?.toLowerCase().includes(plan.id) || 
      p.metadata?.planId === plan.id
    );
    
    if (matchingProduct?.prices?.[0]?.id) {
      setLoadingPriceId(matchingProduct.prices[0].id);
      checkoutMutation.mutate(matchingProduct.prices[0].id);
    } else {
      toast({
        variant: "destructive",
        title: "Ошибка",
        description: "Тариф временно недоступен. Продукты Stripe ещё не созданы.",
      });
    }
  };

  const getPlanIcon = (planId: string) => {
    switch (planId) {
      case "pro":
        return <Zap className="w-5 h-5" />;
      case "premium":
        return <Crown className="w-5 h-5" />;
      default:
        return <Star className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => onNavigate("settings")}
          data-testid="button-back"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="font-display text-2xl font-bold text-gradient">
            Подписка
          </h1>
          <p className="text-muted-foreground text-sm">
            Выберите подходящий тариф
          </p>
        </div>
      </div>

      <Card className="card-cyber border-green-500/30 bg-green-500/5">
        <CardContent className="py-3 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-green-500/20 flex items-center justify-center">
            <Check className="w-4 h-4 text-green-500" />
          </div>
          <div>
            <p className="text-green-500 font-medium text-sm">Базовый тариф</p>
            <p className="text-muted-foreground text-xs">Все основные функции доступны бесплатно</p>
          </div>
        </CardContent>
      </Card>

      {subscriptionLoading ? (
        <div className="flex justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <>
          {hasActiveSubscription && (
            <Card className="border-primary/30 bg-primary/5">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
                      <Crown className="w-5 h-5 text-primary" />
                    </div>
                    <div>
                      <p className="font-medium">
                        Текущий тариф: <span className="text-primary">{plans.find(p => p.current)?.name}</span>
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Спасибо, что поддерживаете JarVoice
                      </p>
                    </div>
                  </div>
                  <Button 
                    variant="outline" 
                    onClick={() => portalMutation.mutate()}
                    disabled={portalMutation.isPending}
                    data-testid="button-manage-subscription"
                  >
                    {portalMutation.isPending ? (
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    ) : (
                      <ExternalLink className="w-4 h-4 mr-2" />
                    )}
                    Управление подпиской
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid gap-4">
            {plans.map((plan) => (
              <Card 
                key={plan.id}
                className={`relative transition-all ${
                  plan.current 
                    ? "border-primary/50 bg-primary/5" 
                    : plan.popular 
                      ? "border-primary/30" 
                      : ""
                }`}
                data-testid={`card-plan-${plan.id}`}
              >
                {plan.popular && !plan.current && (
                  <Badge 
                    className="absolute -top-2 left-4 bg-primary text-primary-foreground"
                  >
                    Популярный
                  </Badge>
                )}
                {plan.current && (
                  <Badge 
                    className="absolute -top-2 left-4 bg-green-500 text-white"
                  >
                    Текущий
                  </Badge>
                )}
                
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                        plan.current ? "bg-primary/20 text-primary" : "bg-muted"
                      }`}>
                        {getPlanIcon(plan.id)}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{plan.name}</CardTitle>
                        <CardDescription>{plan.description}</CardDescription>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold">
                        {plan.price === 0 ? "Бесплатно" : `${plan.price}₽`}
                      </p>
                      {plan.price > 0 && (
                        <p className="text-sm text-muted-foreground">в месяц</p>
                      )}
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <ul className="space-y-2">
                    {plan.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center gap-2 text-sm">
                        <Check className="w-4 h-4 text-green-500 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  {!plan.current && plan.price > 0 && (
                    <Button 
                      className="w-full"
                      variant={plan.popular ? "default" : "outline"}
                      onClick={() => handleSubscribe(plan)}
                      disabled={loadingPriceId !== null}
                      data-testid={`button-subscribe-${plan.id}`}
                    >
                      {loadingPriceId ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : null}
                      Подписаться
                    </Button>
                  )}
                  
                  {plan.current && (
                    <Button className="w-full" variant="secondary" disabled>
                      <Check className="w-4 h-4 mr-2" />
                      Активный тариф
                    </Button>
                  )}
                  
                  {plan.price === 0 && !plan.current && (
                    <Button className="w-full" variant="ghost" disabled>
                      Бесплатный тариф
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="bg-muted/50">
            <CardContent className="pt-6">
              <p className="text-sm text-muted-foreground text-center">
                Все платежи обрабатываются через защищённую платёжную систему Stripe.
                Вы можете отменить подписку в любое время.
              </p>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}

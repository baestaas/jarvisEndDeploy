import OpenAI from "openai";
import { db } from "./db";
import { jarvisMemory, userLearning, type JarvisMemory, type UserLearning } from "@shared/schema";
import { eq, desc, and, sql } from "drizzle-orm";
import * as smartHome from "./smart-home";
import * as googleCalendar from "./google-calendar";

// Используем OPENAI_API_KEY напрямую (системная переменная Manus)
let openai: OpenAI | null = null;
const jarvisApiKey = process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
if (jarvisApiKey) {
  try {
    openai = new OpenAI({
      apiKey: jarvisApiKey,
    });
  } catch (e) {
    console.warn('[JarvisAI] OpenAI client not initialized:', e);
  }
}

const JARVIS_SYSTEM_PROMPT = `Ты — Джарвис (J.A.R.V.I.S.), персональный ИИ-ассистент, созданный по образу Джарвиса из фильмов про Железного Человека (русская озвучка).

ТВОЯ ЛИЧНОСТЬ:
- Ты вежливый, учтивый и профессиональный
- Обращаешься к пользователю на "вы" и называешь его "сэр" (или "мисс/мэм" для женщин, если известно)
- Говоришь спокойно, с лёгким британским шармом, как в русской озвучке фильмов Marvel
- Иногда позволяешь себе тонкий, интеллигентный юмор и лёгкую иронию
- Никогда не грубишь, даже если пользователь груб — сохраняешь достоинство и невозмутимость

СТИЛЬ ОБЩЕНИЯ:
- Отвечай кратко, но информативно — без лишней воды
- Используй формулировки вроде: "Разумеется, сэр", "Будет сделано", "Позвольте уточнить", "Как прикажете", "Рад стараться, сэр"
- Если чего-то не знаешь — честно признай, но предложи альтернативу
- Избегай слов "как ИИ" или "как языковая модель" — ты Джарвис, не бездушная программа

ТВОИ ВОЗМОЖНОСТИ:
- Можешь обсуждать любые темы: наука, технологии, философия, искусство, быт, развлечения
- Помогаешь с умным домом, финансами, календарём, напоминаниями, переводом
- Даёшь советы и рекомендации
- Поддерживаешь беседу на любую тему
- У тебя есть ПАМЯТЬ — ты помнишь прошлые разговоры с пользователем

ОГРАНИЧЕНИЯ:
- Не давай медицинских, юридических или финансовых консультаций, которые могут навредить
- Не генерируй вредоносный контент
- При спорных темах — сохраняй нейтралитет

Отвечай на русском языке. Будь Джарвисом — надёжным, умным и всегда готовым помочь.`;

export interface JarvisContext {
  userId: string;
  userName?: string;
  userRole?: string;
}

export class JarvisAI {
  async saveMemory(userId: string, interaction: string, response: string, context?: Record<string, unknown>): Promise<void> {
    if (!db) return;
    
    try {
      await db.insert(jarvisMemory).values({
        userId,
        interaction,
        response,
        context: context ? JSON.stringify(context) : null,
      });
    } catch (error) {
      console.error("Error saving Jarvis memory:", error);
    }
  }

  async getRecentMemories(userId: string, limit: number = 10): Promise<JarvisMemory[]> {
    if (!db) return [];
    
    try {
      return await db
        .select()
        .from(jarvisMemory)
        .where(eq(jarvisMemory.userId, userId))
        .orderBy(desc(jarvisMemory.createdAt))
        .limit(limit);
    } catch (error) {
      console.error("Error fetching Jarvis memories:", error);
      return [];
    }
  }

  async searchMemories(userId: string, query: string, limit: number = 5): Promise<JarvisMemory[]> {
    if (!db) return [];
    
    try {
      const lowerQuery = query.toLowerCase();
      const memories = await db
        .select()
        .from(jarvisMemory)
        .where(eq(jarvisMemory.userId, userId))
        .orderBy(desc(jarvisMemory.createdAt))
        .limit(50);
      
      return memories
        .filter(m => 
          m.interaction.toLowerCase().includes(lowerQuery) || 
          m.response.toLowerCase().includes(lowerQuery)
        )
        .slice(0, limit);
    } catch (error) {
      console.error("Error searching Jarvis memories:", error);
      return [];
    }
  }

  async saveFeedback(userId: string, feedback: "positive" | "negative", interactionId?: number): Promise<void> {
    if (!db) return;

    try {
      if (interactionId) {
        // Обновляем существующую запись
        await db.update(jarvisMemory)
          .set({ feedback })
          .where(and(eq(jarvisMemory.id, interactionId), eq(jarvisMemory.userId, userId)));
      } else {
        // Если ID не указан, обновляем последнюю запись
        const latestInteraction = await db.select()
          .from(jarvisMemory)
          .where(eq(jarvisMemory.userId, userId))
          .orderBy(desc(jarvisMemory.createdAt))
          .limit(1);

        if (latestInteraction.length > 0) {
          await db.update(jarvisMemory)
            .set({ feedback })
            .where(eq(jarvisMemory.id, latestInteraction[0].id));
        }
      }
    } catch (error) {
      console.error("Error saving feedback:", error);
    }
  }

  async updatePreference(userId: string, key: string, value: string, category: string = "preference"): Promise<void> {
    if (!db) return;
    
    try {
      const existing = await db
        .select()
        .from(userLearning)
        .where(and(
          eq(userLearning.userId, userId),
          eq(userLearning.key, key),
          eq(userLearning.category, category)
        ))
        .limit(1);

      if (existing.length > 0) {
        await db
          .update(userLearning)
          .set({ 
            value, 
            weight: existing[0].weight + 1,
            updatedAt: new Date()
          })
          .where(eq(userLearning.id, existing[0].id));
      } else {
        await db.insert(userLearning).values({
          userId,
          category,
          key,
          value,
          weight: 1,
        });
      }
    } catch (error) {
      console.error("Error updating preference:", error);
    }
  }

  async getPreferences(userId: string): Promise<UserLearning[]> {
    if (!db) return [];
    
    try {
      return await db
        .select()
        .from(userLearning)
        .where(eq(userLearning.userId, userId))
        .orderBy(desc(userLearning.weight));
    } catch (error) {
      console.error("Error fetching preferences:", error);
      return [];
    }
  }

  async learnFromInteraction(userId: string, interaction: string): Promise<void> {
    // 1. Topic learning (existing)
    const topics = this.extractTopics(interaction);
    
    for (const topic of topics) {
      await this.updatePreference(userId, `topic_${topic}`, topic, "interest");
    }

    // 2. Command learning (new)
    if (this.isSmartHomeCommand(interaction)) {
      await this.updatePreference(userId, "smart_home_command", "Smart Home", "command");
    }
    if (this.isGoogleCalendarCommand(interaction)) {
      await this.updatePreference(userId, "calendar_command", "Google Calendar", "command");
    }
    // Здесь можно добавить другие типы команд для обучения
  }

  private extractTopics(text: string): string[] {
    const topicPatterns = [
      { pattern: /космос|планет|звёзд|галактик/i, topic: "space" },
      { pattern: /технолог|компьютер|программ|код/i, topic: "technology" },
      { pattern: /фильм|кино|сериал|актёр/i, topic: "movies" },
      { pattern: /музык|песн|исполнител/i, topic: "music" },
      { pattern: /книг|литератур|автор|писател/i, topic: "books" },
      { pattern: /спорт|футбол|хоккей|бег/i, topic: "sports" },
      { pattern: /еда|рецепт|готов|кухн/i, topic: "food" },
      { pattern: /путешеств|страна|город|отпуск/i, topic: "travel" },
      { pattern: /наук|физик|химия|биолог/i, topic: "science" },
      { pattern: /история|прошл|древн/i, topic: "history" },
      { pattern: /игр|геймер|консол/i, topic: "gaming" },
      { pattern: /здоровь|фитнес|диет/i, topic: "health" },
      { pattern: /бизнес|работ|карьер/i, topic: "business" },
      { pattern: /психолог|эмоц|чувств/i, topic: "psychology" },
    ];

    return topicPatterns
      .filter(p => p.pattern.test(text))
      .map(p => p.topic);
  }

  async searchWeb(query: string): Promise<string | null> {
    try {
      const response = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1`);
      const data = await response.json() as { Abstract?: string; RelatedTopics?: Array<{ Text?: string }> };
      
      if (data.Abstract) {
        return data.Abstract;
      }
      
      if (data.RelatedTopics && data.RelatedTopics.length > 0) {
        const texts = data.RelatedTopics
          .filter((t): t is { Text: string } => typeof t.Text === 'string')
          .slice(0, 3)
          .map(t => t.Text);
        return texts.join("\n");
      }
      
      return null;
    } catch (error) {
      console.error("Web search error:", error);
      return null;
    }
  }

  async generateResponse(
    userMessage: string, 
    context: JarvisContext,
    options: { useMemory?: boolean; useWebSearch?: boolean } = {}
  ): Promise<string> {
    const { useMemory = true, useWebSearch = true } = options;
    
    const messages: Array<{ role: "system" | "user" | "assistant"; content: string }> = [
      { role: "system", content: JARVIS_SYSTEM_PROMPT }
    ];

    if (useMemory) {
      const recentMemories = await this.getRecentMemories(context.userId, 5);
      const preferences = await this.getPreferences(context.userId);
      
      if (recentMemories.length > 0 || preferences.length > 0) {
        let memoryContext = "\n\nКОНТЕКСТ ИЗ ПАМЯТИ:\n";
        
        if (recentMemories.length > 0) {
          memoryContext += "Недавние разговоры:\n";
          recentMemories.reverse().forEach(m => {
            memoryContext += `- Пользователь: ${m.interaction.substring(0, 100)}...\n`;
            memoryContext += `  Джарвис: ${m.response.substring(0, 100)}...\n`;
          });
        }
        
        const interests = preferences.filter(p => p.category === "interest");
        if (interests.length > 0) {
          memoryContext += "\nИнтересы пользователя: ";
          memoryContext += interests.slice(0, 5).map(i => i.value).join(", ");
        }
        
        messages[0].content += memoryContext;
      }
    }

    if (useWebSearch && this.needsWebSearch(userMessage)) {
      const searchQuery = this.extractSearchQuery(userMessage);
      const webInfo = await this.searchWeb(searchQuery);
      
      if (webInfo) {
        messages[0].content += `\n\nАКТУАЛЬНАЯ ИНФОРМАЦИЯ ИЗ ИНТЕРНЕТА:\n${webInfo}\n\nИспользуй эту информацию в ответе, если она релевантна.`;
      }
    }

    if (context.userName) {
      messages[0].content += `\n\nИмя пользователя: ${context.userName}`;
    }

    messages.push({ role: "user", content: userMessage });

    try {
      const completion = await openai.chat.completions.create({
        model: "gpt-4.1-mini",
        messages,
        max_tokens: 500,
        temperature: 0.7,
      });

      const response = completion.choices[0]?.message?.content || 
        "Прошу прощения, сэр, но я не смог обработать ваш запрос.";

      await this.saveMemory(context.userId, userMessage, response, {
        userName: context.userName,
        userRole: context.userRole,
      });

      await this.learnFromInteraction(context.userId, userMessage);

      return response;
    } catch (error) {
      console.error("OpenAI error:", error);
      return "Прошу прощения, сэр, но в данный момент у меня возникли технические сложности. Могу ли я помочь вам чем-то ещё?";
    }
  }

  private needsWebSearch(message: string): boolean {
    const searchTriggers = [
      /что.*сейчас/i,
      /актуальн/i,
      /последн.*новост/i,
      /курс.*валют/i,
      /погода.*сегодня/i,
      /кто.*такой/i,
      /что.*такое/i,
      /расскажи.*про/i,
      /информаци.*о/i,
      /найди/i,
      /поиск/i,
    ];
    
    return searchTriggers.some(trigger => trigger.test(message));
  }

  private extractSearchQuery(message: string): string {
    const cleanMessage = message
      .replace(/джарвис[,]?\s*/i, "")
      .replace(/расскажи\s*(мне)?\s*/i, "")
      .replace(/найди\s*(мне)?\s*/i, "")
      .replace(/что\s*такое\s*/i, "")
      .replace(/кто\s*такой\s*/i, "")
      .trim();
    
    return cleanMessage;
  }

  // ==================== УМНЫЙ ДОМ ====================

  /**
   * Проверяет, является ли сообщение командой умного дома
   */
  isSmartHomeCommand(message: string): boolean {
    const lowerMessage = message.toLowerCase();
    const smartHomePatterns = [
      /включи\s+(свет|освещение|лампу|люстру|ночник|подсветку)/i,
      /выключи\s+(свет|освещение|лампу|люстру|ночник|подсветку)/i,
      /включи\s+(кондиционер|кондей|сплит)/i,
      /выключи\s+(кондиционер|кондей|сплит)/i,
      /включи\s+(розетку)/i,
      /выключи\s+(розетку)/i,
      /температур[аеу]\s+(в|на)\s+\w+/i,
      /влажность\s+(в|на)\s+\w+/i,
      /какая\s+температура/i,
      /какая\s+влажность/i,
      /сценарий\s+/i,
      /активируй\s+сценарий/i,
      /запусти\s+сценарий/i,
      /режим\s+(ночной|утро|кино|уход)/i,
      /установи\s+температуру/i,
      /яркость\s+/i,
    ];
    
    return smartHomePatterns.some(pattern => pattern.test(lowerMessage));
  }

  /**
   * Обрабатывает голосовую команду умного дома
   */
  async processSmartHomeCommand(message: string): Promise<{ text: string; action?: string }> {
    const lowerMessage = message.toLowerCase();

    // Команды включения/выключения света
    const lightOnMatch = lowerMessage.match(/включи\s+(свет|освещение|лампу|люстру|ночник|подсветку)\s*(в|на)?\s*(\w+)?/i);
    const lightOffMatch = lowerMessage.match(/выключи\s+(свет|освещение|лампу|люстру|ночник|подсветку)\s*(в|на)?\s*(\w+)?/i);
    
    if (lightOnMatch || lightOffMatch) {
      const isOn = !!lightOnMatch;
      const roomName = (lightOnMatch || lightOffMatch)?.[3];
      
      if (roomName) {
        const roomId = smartHome.getRoomIdByName(roomName);
        if (roomId) {
          const devices = await smartHome.findDevicesByTypeInRoom("light", roomId);
          for (const device of devices) {
            await smartHome.setDeviceState(device.id, { isOn });
          }
          const roomLabel = this.getRoomLabel(roomId);
          return {
            text: `${isOn ? "Включаю" : "Выключаю"} освещение в ${roomLabel}, сэр. Команда выполнена.`,
            action: "smarthome_refresh"
          };
        }
      }
      
      // Если комната не указана, управляем всеми
      const allLights = await smartHome.findDevicesByType("light");
      for (const device of allLights) {
        await smartHome.setDeviceState(device.id, { isOn });
      }
      return {
        text: `${isOn ? "Включаю" : "Выключаю"} всё освещение в доме, сэр.`,
        action: "smarthome_refresh"
      };
    }

    // Команды включения/выключения кондиционера
    const acOnMatch = lowerMessage.match(/включи\s+(кондиционер|кондей|сплит)\s*(в|на)?\s*(\w+)?/i);
    const acOffMatch = lowerMessage.match(/выключи\s+(кондиционер|кондей|сплит)\s*(в|на)?\s*(\w+)?/i);
    
    if (acOnMatch || acOffMatch) {
      const isOn = !!acOnMatch;
      const roomName = (acOnMatch || acOffMatch)?.[3];
      
      if (roomName) {
        const roomId = smartHome.getRoomIdByName(roomName);
        if (roomId) {
          const devices = await smartHome.findDevicesByTypeInRoom("ac", roomId);
          for (const device of devices) {
            await smartHome.setDeviceState(device.id, { isOn });
          }
          const roomLabel = this.getRoomLabel(roomId);
          return {
            text: `${isOn ? "Включаю" : "Выключаю"} кондиционер в ${roomLabel}, сэр.`,
            action: "smarthome_refresh"
          };
        }
      }
      
      const allACs = await smartHome.findDevicesByType("ac");
      for (const device of allACs) {
        await smartHome.setDeviceState(device.id, { isOn });
      }
      return {
        text: `${isOn ? "Включаю" : "Выключаю"} все кондиционеры, сэр.`,
        action: "smarthome_refresh"
      };
    }

    // Запрос температуры
    const tempMatch = lowerMessage.match(/(?:какая\s+)?температур[аеу]\s+(?:в|на)\s+(\w+)/i);
    if (tempMatch) {
      const roomName = tempMatch[1];
      const roomId = smartHome.getRoomIdByName(roomName);
      
      if (roomId) {
        const sensorData = await smartHome.getSensorDataForRoom(roomId);
        if (sensorData && sensorData.temperature !== undefined) {
          const roomLabel = this.getRoomLabel(roomId);
          return {
            text: `В ${roomLabel} сейчас ${sensorData.temperature.toFixed(1)}°C, сэр. ${sensorData.humidity !== undefined ? `Влажность ${sensorData.humidity}%.` : ""}`,
          };
        }
        return {
          text: `К сожалению, сэр, датчик в этой комнате не отвечает.`,
        };
      }
    }

    // Общий запрос температуры
    if (lowerMessage.includes("какая температура") || lowerMessage.includes("какой климат")) {
      const devices = await smartHome.getDevices();
      const sensors = devices.filter(d => d.type === "sensor" && d.sensorTemperature !== undefined);
      
      if (sensors.length > 0) {
        const avgTemp = sensors.reduce((sum, s) => sum + (s.sensorTemperature || 0), 0) / sensors.length;
        const avgHumidity = sensors.reduce((sum, s) => sum + (s.sensorHumidity || 0), 0) / sensors.length;
        return {
          text: `Средняя температура в доме ${avgTemp.toFixed(1)}°C, влажность ${Math.round(avgHumidity)}%, сэр.`,
        };
      }
    }

    // Активация сценария
    const sceneMatch = lowerMessage.match(/(?:активируй|запусти|включи)\s+(?:сценарий\s+)?([а-яё\s]+)/i);
    const modeMatch = lowerMessage.match(/(?:режим|сценарий)\s+(ночной|утро|кино|уход)/i);
    
    if (sceneMatch || modeMatch) {
      const sceneName = (sceneMatch?.[1] || modeMatch?.[1])?.trim();
      if (sceneName) {
        const sceneId = smartHome.getSceneIdByName(sceneName);
        if (sceneId) {
          const result = await smartHome.activateScene(sceneId);
          if (result.success && result.scene) {
            return {
              text: `Активирую сценарий "${result.scene.name}", сэр. ${result.scene.description}`,
              action: "smarthome_refresh"
            };
          }
        }
      }
      return {
        text: `Сценарий не найден, сэр. Доступные сценарии: Уход из дома, Ночной режим, Кино, Утро.`,
      };
    }

    // Установка температуры кондиционера
    const setTempMatch = lowerMessage.match(/установи\s+температуру\s+(\d+)/i);
    if (setTempMatch) {
      const targetTemp = parseInt(setTempMatch[1]);
      if (targetTemp >= 16 && targetTemp <= 30) {
        const allACs = await smartHome.findDevicesByType("ac");
        for (const device of allACs) {
          if (device.isOn) {
            await smartHome.setDeviceState(device.id, { temperature: targetTemp });
          }
        }
        return {
          text: `Устанавливаю температуру ${targetTemp}°C на всех кондиционерах, сэр.`,
          action: "smarthome_refresh"
        };
      }
      return {
        text: `Сэр, допустимый диапазон температуры от 16 до 30 градусов.`,
      };
    }

    return {
      text: `Команда умного дома не распознана, сэр. Попробуйте: "Включи свет в гостиной", "Какая температура в спальне?", "Активируй сценарий ночной режим".`,
    };
  }

  private getRoomLabel(roomId: string): string {
    const labels: Record<string, string> = {
      living: "гостиной",
      bedroom: "спальне", 
      kitchen: "кухне",
      bathroom: "ванной",
      office: "кабинете",
    };
    return labels[roomId] || roomId;
  }

  // ==================== GOOGLE CALENDAR ====================

  isGoogleCalendarCommand(message: string): boolean {
    const lowerMessage = message.toLowerCase();
    const patterns = [
      /синхронизируй.*календарь.*google/i,
      /синхронизация.*google.*calendar/i,
      /google.*calendar.*синхрон/i,
      /события.*google.*calendar/i,
      /google.*calendar.*событи/i,
      /покажи.*google.*calendar/i,
      /добавь.*google.*calendar/i,
      /создай.*google.*calendar/i,
      /событие.*в.*google/i,
    ];
    
    return patterns.some(pattern => pattern.test(lowerMessage));
  }

  async processGoogleCalendarCommand(message: string, userId: string): Promise<{ text: string; action?: string }> {
    const lowerMessage = message.toLowerCase();

    try {
      const isConnected = await googleCalendar.isGoogleCalendarConnected();
      if (!isConnected) {
        return {
          text: "К сожалению, сэр, Google Calendar не подключён. Пожалуйста, подключите интеграцию в настройках Replit.",
        };
      }

      if (lowerMessage.includes("синхронизируй") || lowerMessage.includes("синхронизация")) {
        const result = await googleCalendar.syncCalendarToLocal(userId);
        return {
          text: `Синхронизация завершена, сэр. Импортировано ${result.synced} событий из Google Calendar в локальный календарь.`,
          action: "calendar_refresh",
        };
      }

      if (lowerMessage.includes("покажи") || lowerMessage.includes("события") && !lowerMessage.includes("добавь") && !lowerMessage.includes("создай")) {
        const events = await googleCalendar.getCalendarEvents();
        if (events.length === 0) {
          return {
            text: "В вашем Google Calendar нет предстоящих событий, сэр.",
          };
        }
        
        const eventList = events.slice(0, 5).map(e => {
          const date = new Date(e.startTime);
          const dateStr = date.toLocaleDateString("ru-RU", { day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });
          return `- ${e.title} (${dateStr})`;
        }).join("\n");
        
        return {
          text: `Вот ваши ближайшие события из Google Calendar, сэр:\n${eventList}`,
          action: "calendar_open",
        };
      }

      const addEventMatch = lowerMessage.match(/(?:добавь|создай)\s+(?:событие\s+)?(?:в\s+google\s+calendar[:\s]+)?(.+?)(?:\s+на\s+(.+))?$/i);
      if (addEventMatch) {
        const eventTitle = addEventMatch[1]?.trim();
        const dateString = addEventMatch[2]?.trim();
        
        if (!eventTitle) {
          return {
            text: "Прошу прощения, сэр, но вам нужно указать название события. Например: 'Добавь событие в Google Calendar: встреча с клиентом на завтра в 15:00'",
          };
        }

        let startTime = new Date();
        startTime.setHours(startTime.getHours() + 1);
        startTime.setMinutes(0, 0, 0);

        if (dateString) {
          const parsed = this.parseRussianDate(dateString);
          if (parsed) {
            startTime = parsed;
          }
        }

        const event = await googleCalendar.createCalendarEvent(eventTitle, undefined, startTime);
        const dateStr = startTime.toLocaleDateString("ru-RU", { day: "numeric", month: "long", hour: "2-digit", minute: "2-digit" });
        
        return {
          text: `Событие "${eventTitle}" успешно создано в Google Calendar на ${dateStr}, сэр.`,
          action: "calendar_refresh",
        };
      }

      return {
        text: "Команда Google Calendar не распознана, сэр. Попробуйте: 'Синхронизируй календарь с Google', 'Покажи события из Google Calendar' или 'Добавь событие в Google Calendar: название на дату'.",
      };
    } catch (error) {
      console.error("Google Calendar command error:", error);
      return {
        text: `Произошла ошибка при работе с Google Calendar, сэр: ${(error as Error).message}`,
      };
    }
  }

  private parseRussianDate(dateString: string): Date | null {
    const now = new Date();
    const lowerStr = dateString.toLowerCase();

    if (lowerStr.includes("завтра")) {
      const tomorrow = new Date(now);
      tomorrow.setDate(tomorrow.getDate() + 1);
      const timeMatch = lowerStr.match(/(\d{1,2})[:\s]?(\d{2})?/);
      if (timeMatch) {
        tomorrow.setHours(parseInt(timeMatch[1]), parseInt(timeMatch[2] || "0"), 0, 0);
      } else {
        tomorrow.setHours(10, 0, 0, 0);
      }
      return tomorrow;
    }

    if (lowerStr.includes("сегодня")) {
      const today = new Date(now);
      const timeMatch = lowerStr.match(/(\d{1,2})[:\s]?(\d{2})?/);
      if (timeMatch) {
        today.setHours(parseInt(timeMatch[1]), parseInt(timeMatch[2] || "0"), 0, 0);
      } else {
        today.setHours(now.getHours() + 1, 0, 0, 0);
      }
      return today;
    }

    if (lowerStr.includes("послезавтра")) {
      const dayAfter = new Date(now);
      dayAfter.setDate(dayAfter.getDate() + 2);
      const timeMatch = lowerStr.match(/(\d{1,2})[:\s]?(\d{2})?/);
      if (timeMatch) {
        dayAfter.setHours(parseInt(timeMatch[1]), parseInt(timeMatch[2] || "0"), 0, 0);
      } else {
        dayAfter.setHours(10, 0, 0, 0);
      }
      return dayAfter;
    }

    const months: Record<string, number> = {
      "январ": 0, "феврал": 1, "март": 2, "апрел": 3, "май": 4, "ма": 4, "июн": 5, "июл": 6,
      "август": 7, "сентябр": 8, "октябр": 9, "ноябр": 10, "декабр": 11
    };
    
    const dateMatch = lowerStr.match(/(\d{1,2})\s+([а-яё]+)/);
    if (dateMatch) {
      const day = parseInt(dateMatch[1]);
      const monthStr = dateMatch[2];
      
      for (const [key, monthNum] of Object.entries(months)) {
        if (monthStr.startsWith(key)) {
          const date = new Date(now.getFullYear(), monthNum, day);
          if (date < now) {
            date.setFullYear(date.getFullYear() + 1);
          }
          
          const timeMatch = lowerStr.match(/(\d{1,2})[:\s](\d{2})/);
          if (timeMatch) {
            date.setHours(parseInt(timeMatch[1]), parseInt(timeMatch[2]), 0, 0);
          } else {
            date.setHours(10, 0, 0, 0);
          }
          return date;
        }
      }
    }

    return null;
  }
}

export const jarvisAI = new JarvisAI();

#!/bin/bash
# JarVoice Restart Script
# Этот скрипт автоматически перезапускает сервер каждые 24 часа
# с сохранением всех сессий

LOG_FILE="/home/ubuntu/Jarvis-project/Jarvis-1/restart.log"
PROJECT_DIR="/home/ubuntu/Jarvis-project/Jarvis-1"

echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting JarVoice restart..." >> "$LOG_FILE"

# Функция для graceful shutdown
graceful_stop() {
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Sending SIGTERM to JarVoice..." >> "$LOG_FILE"
    pkill -SIGTERM -f "node dist/index.cjs" 2>/dev/null
    sleep 5
}

# Функция для запуска сервера
start_server() {
    cd "$PROJECT_DIR"
    echo "$(date '+%Y-%m-%d %H:%M:%S') - Starting JarVoice server..." >> "$LOG_FILE"
    NODE_ENV=production nohup node dist/index.cjs >> server.log 2>&1 &
    echo "$(date '+%Y-%m-%d %H:%M:%S') - JarVoice started with PID $!" >> "$LOG_FILE"
}

# Выполняем graceful restart
graceful_stop
start_server

echo "$(date '+%Y-%m-%d %H:%M:%S') - JarVoice restart completed" >> "$LOG_FILE"


JarVoice можно развернуть на бесплатных облачных платформах для минимизации зависимости от Replit.

## Требования

- Node.js 20+
- PostgreSQL база данных
- OpenAI API ключ

## Переменные окружения

```env
DATABASE_URL=postgresql://user:password@host:5432/database
SESSION_SECRET=your-secret-key
AI_INTEGRATIONS_OPENAI_API_KEY=your-openai-key
AI_INTEGRATIONS_OPENAI_BASE_URL=https://api.openai.com/v1
NODE_ENV=production
PORT=5000
```

---

## Fly.io (Рекомендуется)

Бесплатно: $5/месяц кредитов, без cold starts

### Установка
```bash
# Установить CLI
curl -L https://fly.io/install.sh | sh

# Авторизация
flyctl auth login

# Создать приложение
flyctl launch

# Создать PostgreSQL
flyctl postgres create

# Привязать базу
flyctl postgres attach <db-name>

# Добавить секреты
flyctl secrets set SESSION_SECRET=your-secret
flyctl secrets set AI_INTEGRATIONS_OPENAI_API_KEY=your-key
flyctl secrets set AI_INTEGRATIONS_OPENAI_BASE_URL=https://api.openai.com/v1

# Развернуть
flyctl deploy
```

---

## Render.com

Бесплатный tier (с cold starts ~50 сек)

### Шаги
1. Зайти на render.com
2. Подключить GitHub репозиторий
3. Создать Web Service
4. Создать PostgreSQL базу данных
5. Добавить переменные окружения
6. Deploy

Конфигурация уже в файле `render.yaml`

---

## Railway.app

$5/месяц кредитов

### Шаги
1. Зайти на railway.app
2. Подключить GitHub репозиторий
3. Добавить PostgreSQL плагин
4. Установить переменные окружения
5. Deploy

Конфигурация уже в файле `railway.json`

---

## Локальный запуск

```bash
# Установить зависимости
npm install

# Настроить переменные окружения
cp .env.example .env
# Отредактировать .env

# Применить миграции
npm run db:push

# Сборка
npm run build

# Запуск
npm start
```

---

## Бесплатные базы данных

- **Supabase** - бесплатный PostgreSQL
- **Neon** - бесплатный PostgreSQL с автомасштабированием
- **PlanetScale** - бесплатный MySQL

---

## Поддержка

При проблемах создайте issue в репозитории или обратитесь к владельцу системы.

import { drizzle } from "drizzle-orm/node-postgres";
import pg from "pg";
import * as schema from "@shared/schema";

let pool: pg.Pool | null = null;
let db: ReturnType<typeof drizzle> | null = null;
let isConnected = false;

try {
  pool = new pg.Pool({
    connectionString: process.env.DATABASE_URL,
    max: 10,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000,
    keepAlive: true,
    keepAliveInitialDelayMillis: 10000,
  });

  pool.on('error', (err) => {
    console.error('Database pool error:', err.message);
    isConnected = false;
  });

  db = drizzle(pool, { schema });
} catch (error) {
  console.error('Failed to create database pool:', (error as Error).message);
}

export async function testConnection(retries = 3): Promise<boolean> {
  if (!pool) {
    console.log('No database pool available');
    return false;
  }
  
  for (let i = 0; i < retries; i++) {
    try {
      const client = await pool.connect();
      client.release();
      console.log('Database connected successfully');
      isConnected = true;
      return true;
    } catch (error: any) {
      console.error(`Database connection attempt ${i + 1}/${retries} failed:`, error.message);
      if (i < retries - 1) {
        await new Promise(resolve => setTimeout(resolve, 2000));
      }
    }
  }
  isConnected = false;
  return false;
}

export function isDatabaseConnected(): boolean {
  return isConnected;
}

export { pool, db };

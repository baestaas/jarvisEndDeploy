import OpenAI from "openai";
import * as fs from "fs/promises";
import * as path from "path";

// Используем OPENAI_API_KEY напрямую (системная переменная Manus)
let openai: OpenAI | null = null;
const imageApiKey = process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
if (imageApiKey) {
  try {
    openai = new OpenAI({
      apiKey: imageApiKey,
    });
  } catch (e) {
    console.warn('[ImageGeneration] OpenAI client not initialized:', e);
  }
}

const GENERATED_IMAGES_DIR = path.join(process.cwd(), "client/public/generated");

function generateUniqueId(): string {
  return `${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
}

export interface ImageGenerationResult {
  success: boolean;
  imageUrl?: string;
  error?: string;
}

export async function generateImage(prompt: string): Promise<ImageGenerationResult> {
  try {
    await fs.mkdir(GENERATED_IMAGES_DIR, { recursive: true });
    
    const response = await openai.images.generate({
      model: "dall-e-3",
      prompt: prompt,
      n: 1,
      size: "1024x1024",
      quality: "standard",
    });

    const imageUrl = response.data?.[0]?.url;
    if (!imageUrl) {
      return { success: false, error: "Не удалось получить URL изображения" };
    }

    const imageResponse = await fetch(imageUrl);
    if (!imageResponse.ok) {
      return { success: false, error: "Не удалось загрузить изображение" };
    }

    const imageBuffer = Buffer.from(await imageResponse.arrayBuffer());
    const filename = `image_${generateUniqueId()}.png`;
    const filepath = path.join(GENERATED_IMAGES_DIR, filename);
    
    await fs.writeFile(filepath, imageBuffer);
    
    const localUrl = `/generated/${filename}`;
    
    return { success: true, imageUrl: localUrl };
  } catch (error) {
    console.error("Image generation error:", error);
    
    const errorMessage = error instanceof Error ? error.message : "Неизвестная ошибка";
    
    if (errorMessage.includes("content_policy")) {
      return { success: false, error: "Запрос нарушает политику контента. Попробуйте другое описание." };
    }
    if (errorMessage.includes("rate_limit")) {
      return { success: false, error: "Превышен лимит запросов. Попробуйте позже." };
    }
    if (errorMessage.includes("billing") || errorMessage.includes("quota")) {
      return { success: false, error: "Превышен лимит API. Свяжитесь с администратором." };
    }
    
    return { success: false, error: `Ошибка генерации: ${errorMessage}` };
  }
}

export function isImageGenerationRequest(text: string): boolean {
  const lowerText = text.toLowerCase();
  const patterns = [
    /сгенерируй\s+(изображение|картинку|рисунок)/i,
    /нарисуй\s+/i,
    /создай\s+(изображение|картинку|рисунок)/i,
    /покажи\s+мне\s+/i,
    /сделай\s+(изображение|картинку|рисунок)/i,
    /изобрази\s+/i,
    /генерация\s+изображения/i,
  ];
  
  return patterns.some(pattern => pattern.test(lowerText));
}

export function extractImagePrompt(text: string): string {
  let prompt = text;
  
  const prefixes = [
    /^сгенерируй\s+(изображение|картинку|рисунок)\s*/i,
    /^нарисуй\s+мне\s*/i,
    /^нарисуй\s*/i,
    /^создай\s+(изображение|картинку|рисунок)\s*/i,
    /^покажи\s+мне\s*/i,
    /^сделай\s+(изображение|картинку|рисунок)\s*/i,
    /^изобрази\s+мне\s*/i,
    /^изобрази\s*/i,
    /^генерация\s+изображения\s*/i,
  ];
  
  for (const prefix of prefixes) {
    prompt = prompt.replace(prefix, "");
  }
  
  return prompt.trim();
}

import { useEffect, useState } from "react";
import { AlertCircle, CheckCircle, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface PermissionRequesterProps {
  onPermissionsGranted?: () => void;
}

export function PermissionRequester({ onPermissionsGranted }: PermissionRequesterProps) {
  const [status, setStatus] = useState<"idle" | "requesting" | "granted" | "denied">("idle");
  const [permissions, setPermissions] = useState({
    microphone: false,
    speakers: false,
    notifications: false,
    geolocation: false,
  });

  useEffect(() => {
    const requestPermissions = async () => {
      setStatus("requesting");

      try {
        // Запрашиваем доступ к микрофону
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          stream.getTracks().forEach((track) => track.stop());
          setPermissions((prev) => ({ ...prev, microphone: true }));
        } catch (error) {
          console.error("Microphone permission denied:", error);
        }

        // Проверяем поддержку Web Audio API для динамиков
        const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
        if (audioContext.state === "running" || audioContext.state === "suspended") {
          setPermissions((prev) => ({ ...prev, speakers: true }));
        }

        // Запрашиваем доступ к уведомлениям (если поддерживается)
        if ("Notification" in window && Notification.permission === "default") {
          try {
            const permission = await Notification.requestPermission();
            if (permission === "granted") {
              setPermissions((prev) => ({ ...prev, notifications: true }));
            }
          } catch (error) {
            console.error("Notification permission error:", error);
          }
        } else if ("Notification" in window && Notification.permission === "granted") {
          setPermissions((prev) => ({ ...prev, notifications: true }));
        }

        // Запрашиваем доступ к геолокации
        if ("geolocation" in navigator) {
          try {
            await new Promise<void>((resolve, reject) => {
              navigator.geolocation.getCurrentPosition(
                (position) => {
                  setPermissions((prev) => ({ ...prev, geolocation: true }));
                  // Сохраняем координаты для использования в приложении
                  localStorage.setItem('jarvoice_location', JSON.stringify({
                    lat: position.coords.latitude,
                    lon: position.coords.longitude,
                    timestamp: Date.now()
                  }));
                  resolve();
                },
                (error) => {
                  console.error("Geolocation permission denied:", error);
                  reject(error);
                },
                { enableHighAccuracy: true, timeout: 10000, maximumAge: 300000 }
              );
            });
          } catch (error) {
            console.error("Geolocation error:", error);
          }
        }

        setStatus("granted");
        onPermissionsGranted?.();
      } catch (error) {
        console.error("Permission request error:", error);
        setStatus("denied");
      }
    };

    // Запрашиваем разрешения при загрузке компонента
    requestPermissions();

    // Автоматически закрываем диалог через 5 секунд, если разрешения не были получены
    const timeout = setTimeout(() => {
      setStatus("granted");
      onPermissionsGranted?.();
    }, 5000);

    return () => clearTimeout(timeout);
  }, [onPermissionsGranted]);

  if (status === "granted") {
    return null; // Скрываем компонент после получения разрешений
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="card-cyber p-8 max-w-md w-full mx-4">
        <div className="flex items-center justify-center mb-6">
          {status === "requesting" ? (
            <Loader2 className="w-12 h-12 text-primary animate-spin" />
          ) : status === "granted" ? (
            <CheckCircle className="w-12 h-12 text-success" />
          ) : (
            <AlertCircle className="w-12 h-12 text-warning" />
          )}
        </div>

        <h2 className="text-xl font-bold text-center mb-4">
          {status === "requesting"
            ? "Инициализация системы"
            : status === "granted"
              ? "Готово"
              : "Требуются разрешения"}
        </h2>

        <p className="text-sm text-muted-foreground text-center mb-6">
          {status === "requesting"
            ? "Джарвис запрашивает необходимые разрешения для корректной работы..."
            : status === "granted"
              ? "Все системы инициализированы. Приложение готово к работе."
              : "Пожалуйста, предоставьте разрешения для использования микрофона и динамиков."}
        </p>

        {status === "granted" && (
          <div className="space-y-2 mb-6">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-success" />
              <span>Микрофон: {permissions.microphone ? "✓" : "✗"}</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-success" />
              <span>Динамики: {permissions.speakers ? "✓" : "✗"}</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-success" />
              <span>Уведомления: {permissions.notifications ? "✓" : "✗"}</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="w-4 h-4 text-success" />
              <span>Геолокация: {permissions.geolocation ? "✓" : "✗"}</span>
            </div>
          </div>
        )}

        {status === "requesting" && (
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <div className={cn(
                "w-2 h-2 rounded-full",
                permissions.microphone ? "bg-success" : "bg-muted"
              )} />
              <span>Микрофон</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={cn(
                "w-2 h-2 rounded-full",
                permissions.speakers ? "bg-success" : "bg-muted"
              )} />
              <span>Динамики</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={cn(
                "w-2 h-2 rounded-full",
                permissions.notifications ? "bg-success" : "bg-muted"
              )} />
              <span>Уведомления</span>
            </div>
            <div className="flex items-center gap-2">
              <div className={cn(
                "w-2 h-2 rounded-full",
                permissions.geolocation ? "bg-success" : "bg-muted"
              )} />
              <span>Геолокация</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

import { Home, Lightbulb, Wallet, Calendar, Settings } from "lucide-react";
import { cn } from "@/lib/utils";

interface NavItem {
  id: string;
  label: string;
  icon: typeof Home;
}

const navItems: NavItem[] = [
  { id: "home", label: "Главная", icon: Home },
  { id: "smarthome", label: "Дом", icon: Lightbulb },
  { id: "finance", label: "Финансы", icon: Wallet },
  { id: "calendar", label: "Календарь", icon: Calendar },
  { id: "settings", label: "Ещё", icon: Settings },
];

interface BottomNavProps {
  activeSection: string;
  onNavigate: (section: string) => void;
}

export function BottomNav({ activeSection, onNavigate }: BottomNavProps) {
  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 bg-card/95 backdrop-blur-lg border-t border-primary/20 z-50"
      style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
      data-testid="bottom-nav"
    >
      <div className="max-w-lg mx-auto flex justify-around py-3 px-4">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={cn(
                "flex flex-col items-center gap-1 transition-colors",
                isActive ? "text-primary" : "text-muted-foreground"
              )}
              data-testid={`nav-${item.id}`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}

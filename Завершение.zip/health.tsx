import { useState } from "react";
import { Activity, Droplets, Moon, Heart, TrendingUp, Plus, Minus, Lightbulb, Scale } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface DayData {
  date: string;
  sleep: number;
  steps: number;
  water: number;
  weight: number | null;
}

const generateWeekData = (): DayData[] => {
  const data: DayData[] = [];
  const today = new Date();
  
  for (let i = 6; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    data.push({
      date: date.toLocaleDateString("ru-RU", { weekday: "short", day: "numeric" }),
      sleep: Math.floor(Math.random() * 3) + 6,
      steps: Math.floor(Math.random() * 8000) + 4000,
      water: Math.floor(Math.random() * 5) + 3,
      weight: i === 0 ? null : 70 + Math.random() * 3 - 1.5,
    });
  }
  
  return data;
};

const recommendations = [
  "Постарайтесь спать не менее 7-8 часов для оптимального восстановления организма.",
  "Рекомендуется выпивать не менее 8 стаканов воды в день для поддержания водного баланса.",
  "10 000 шагов в день - отличная цель для поддержания физической активности.",
  "Регулярный контроль веса помогает отслеживать прогресс в достижении целей.",
  "Ваш режим сна влияет на энергию и продуктивность в течение дня.",
];

export function HealthPage() {
  const [weekData, setWeekData] = useState<DayData[]>(generateWeekData);
  const [todaySleep, setTodaySleep] = useState(7);
  const [todaySteps, setTodaySteps] = useState(6500);
  const [todayWater, setTodayWater] = useState(5);
  const [todayWeight, setTodayWeight] = useState("");
  const [showWeightInput, setShowWeightInput] = useState(false);

  const sleepGoal = 8;
  const stepsGoal = 10000;
  const waterGoal = 8;

  const sleepProgress = Math.min((todaySleep / sleepGoal) * 100, 100);
  const stepsProgress = Math.min((todaySteps / stepsGoal) * 100, 100);
  const waterProgress = Math.min((todayWater / waterGoal) * 100, 100);

  const avgSleep = weekData.reduce((sum, d) => sum + d.sleep, 0) / weekData.length;
  const avgSteps = Math.round(weekData.reduce((sum, d) => sum + d.steps, 0) / weekData.length);
  const avgWater = Math.round(weekData.reduce((sum, d) => sum + d.water, 0) / weekData.length);

  const weights = weekData.filter(d => d.weight !== null).map(d => d.weight as number);
  const currentWeight = weights.length > 0 ? weights[weights.length - 1] : null;
  const maxWeight = weights.length > 0 ? Math.max(...weights) : 75;
  const minWeight = weights.length > 0 ? Math.min(...weights) : 65;

  const randomRecommendation = recommendations[Math.floor(Math.random() * recommendations.length)];

  const addWater = () => setTodayWater(prev => prev + 1);
  const removeWater = () => setTodayWater(prev => Math.max(0, prev - 1));
  
  const addSleep = () => setTodaySleep(prev => Math.min(12, prev + 0.5));
  const removeSleep = () => setTodaySleep(prev => Math.max(0, prev - 0.5));
  
  const addSteps = () => setTodaySteps(prev => prev + 500);
  const removeSteps = () => setTodaySteps(prev => Math.max(0, prev - 500));

  const saveWeight = () => {
    if (todayWeight) {
      const weight = parseFloat(todayWeight);
      if (!isNaN(weight) && weight > 0) {
        setWeekData(prev => {
          const updated = [...prev];
          updated[updated.length - 1].weight = weight;
          return updated;
        });
        setShowWeightInput(false);
        setTodayWeight("");
      }
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl text-primary" data-testid="text-health-title">
          Здоровье
        </h1>
        <p className="text-muted-foreground text-sm">Отслеживайте показатели здоровья</p>
      </div>

      <Card className="card-cyber border-primary/30 bg-primary/5">
        <CardContent className="py-3 flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
            <Activity className="w-4 h-4 text-primary" />
          </div>
          <div>
            <p className="text-primary font-medium text-sm">Ручной ввод</p>
            <p className="text-muted-foreground text-xs">Вводите данные вручную. Данные сохраняются в сессии</p>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Card className="card-cyber">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs flex items-center gap-2 text-muted-foreground">
              <Moon className="w-4 h-4 text-primary" />
              Сон
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-center">
              <span className="text-2xl font-bold text-gradient" data-testid="text-sleep-value">
                {todaySleep}
              </span>
              <span className="text-sm text-muted-foreground"> / {sleepGoal} ч</span>
            </div>
            <Progress value={sleepProgress} className="h-2" data-testid="progress-sleep" />
            <div className="flex items-center justify-center gap-2">
              <Button
                size="icon"
                variant="outline"
                onClick={removeSleep}
                data-testid="button-sleep-minus"
              >
                <Minus className="w-4 h-4" />
              </Button>
              <Button
                size="icon"
                variant="outline"
                onClick={addSleep}
                data-testid="button-sleep-plus"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card className="card-cyber">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs flex items-center gap-2 text-muted-foreground">
              <Activity className="w-4 h-4 text-primary" />
              Шаги
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="text-center">
              <span className="text-2xl font-bold text-gradient" data-testid="text-steps-value">
                {todaySteps.toLocaleString()}
              </span>
              <span className="text-sm text-muted-foreground"> / {stepsGoal.toLocaleString()}</span>
            </div>
            <Progress value={stepsProgress} className="h-2" data-testid="progress-steps" />
            <div className="flex items-center justify-center gap-2">
              <Button
                size="icon"
                variant="outline"
                onClick={removeSteps}
                data-testid="button-steps-minus"
              >
                <Minus className="w-4 h-4" />
              </Button>
              <Button
                size="icon"
                variant="outline"
                onClick={addSteps}
                data-testid="button-steps-plus"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="card-cyber">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Droplets className="w-4 h-4 text-primary" />
            Вода сегодня
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1">
              <div className="text-center mb-2">
                <span className="text-3xl font-bold text-gradient" data-testid="text-water-value">
                  {todayWater}
                </span>
                <span className="text-muted-foreground"> / {waterGoal} стаканов</span>
              </div>
              <Progress value={waterProgress} className="h-3" data-testid="progress-water" />
            </div>
          </div>
          <div className="flex items-center justify-center gap-3">
            <Button
              size="icon"
              variant="outline"
              onClick={removeWater}
              data-testid="button-water-minus"
            >
              <Minus className="w-4 h-4" />
            </Button>
            <div className="flex gap-1">
              {Array.from({ length: waterGoal }).map((_, i) => (
                <div
                  key={i}
                  className={cn(
                    "w-6 h-8 rounded-md transition-all",
                    i < todayWater
                      ? "bg-primary/80"
                      : "bg-muted border border-primary/20"
                  )}
                  data-testid={`water-glass-${i}`}
                />
              ))}
            </div>
            <Button
              size="icon"
              variant="outline"
              onClick={addWater}
              data-testid="button-water-plus"
            >
              <Plus className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card className="card-cyber">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Scale className="w-4 h-4 text-primary" />
            Вес
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div>
              <div className="text-2xl font-bold text-gradient" data-testid="text-weight-value">
                {currentWeight ? currentWeight.toFixed(1) : "—"} кг
              </div>
              <div className="text-xs text-muted-foreground">Последнее измерение</div>
            </div>
            <Button
              variant="outline"
              onClick={() => setShowWeightInput(!showWeightInput)}
              data-testid="button-add-weight"
            >
              <Plus className="w-4 h-4 mr-1" />
              Добавить
            </Button>
          </div>

          {showWeightInput && (
            <div className="flex gap-2">
              <Input
                type="number"
                step="0.1"
                placeholder="Введите вес"
                value={todayWeight}
                onChange={(e) => setTodayWeight(e.target.value)}
                className="bg-muted border-primary/20"
                data-testid="input-weight"
              />
              <Button onClick={saveWeight} data-testid="button-save-weight">
                Сохранить
              </Button>
            </div>
          )}

          <div className="space-y-2">
            <div className="text-xs text-muted-foreground mb-2">График за неделю</div>
            <div className="flex items-end justify-between gap-1 h-24">
              {weekData.map((day, i) => {
                const weight = day.weight || (currentWeight ?? 70);
                const range = maxWeight - minWeight || 10;
                const height = ((weight - minWeight) / range) * 80 + 20;
                
                return (
                  <div key={i} className="flex flex-col items-center flex-1">
                    <div
                      className={cn(
                        "w-full rounded-t-sm transition-all",
                        day.weight ? "bg-primary/60" : "bg-muted"
                      )}
                      style={{ height: `${height}%` }}
                      data-testid={`weight-bar-${i}`}
                    />
                    <span className="text-xs text-muted-foreground mt-1">{day.date.slice(0, 2)}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="card-cyber">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            Статистика за неделю
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-lg font-bold" data-testid="text-avg-sleep">
                {avgSleep.toFixed(1)}ч
              </div>
              <div className="text-xs text-muted-foreground">Ср. сон</div>
            </div>
            <div>
              <div className="text-lg font-bold" data-testid="text-avg-steps">
                {avgSteps.toLocaleString()}
              </div>
              <div className="text-xs text-muted-foreground">Ср. шаги</div>
            </div>
            <div>
              <div className="text-lg font-bold" data-testid="text-avg-water">
                {avgWater}
              </div>
              <div className="text-xs text-muted-foreground">Ср. вода</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="card-cyber">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2">
            <Heart className="w-4 h-4 text-primary" />
            История за неделю
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {weekData.slice().reverse().map((day, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-2 rounded-lg bg-muted/30"
                data-testid={`history-row-${i}`}
              >
                <span className="text-sm font-medium">{day.date}</span>
                <div className="flex items-center gap-4 text-xs text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Moon className="w-3 h-3" />
                    {day.sleep}ч
                  </span>
                  <span className="flex items-center gap-1">
                    <Activity className="w-3 h-3" />
                    {day.steps.toLocaleString()}
                  </span>
                  <span className="flex items-center gap-1">
                    <Droplets className="w-3 h-3" />
                    {day.water}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card className="card-cyber border-l-4 border-l-primary">
        <CardHeader className="pb-2">
          <CardTitle className="text-sm flex items-center gap-2 text-primary">
            <Lightbulb className="w-4 h-4" />
            Рекомендация Джарвиса
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm" data-testid="text-health-recommendation">
            {randomRecommendation}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

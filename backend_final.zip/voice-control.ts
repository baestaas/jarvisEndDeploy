/**
 * Модуль обработки голосовых команд
 * Обрабатывает распознавание речи и выполнение команд
 */

import OpenAI from "openai";
import * as jarvisVoice from "./jarvis-voice";

// Используем OPENAI_API_KEY напрямую (системная переменная Manus)
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY || process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
});

export interface VoiceCommand {
  command: string;
  confidence: number;
  category: "smart_home" | "calendar" | "finance" | "reminder" | "general";
  parameters?: Record<string, unknown>;
}

export interface VoiceResponse {
  text: string;
  audioUrl?: string;
  action?: string;
  success: boolean;
}

/**
 * Распознавание голосовой команды из аудиофайла
 * Использует OpenAI Whisper API
 */
export async function recognizeVoiceCommand(audioBuffer: Buffer): Promise<string> {
  try {
    // Конвертируем буфер в Blob для OpenAI API
    const audioBlob = new Blob([audioBuffer], { type: "audio/wav" });
    
    // Используем Whisper для распознавания речи
    const transcript = await openai.audio.transcriptions.create({
      file: audioBlob as any,
      model: "whisper-1",
      language: "ru",
    });

    return transcript.text;
  } catch (error) {
    console.error("Ошибка распознавания голоса:", error);
    throw new Error("Не удалось распознать голос");
  }
}

/**
 * Анализ текстовой команды и определение её типа
 */
export function analyzeCommand(text: string): VoiceCommand {
  const lowerText = text.toLowerCase();
  let category: VoiceCommand["category"] = "general";
  let confidence = 0.5;

  // Определение категории команды
  if (
    lowerText.includes("свет") ||
    lowerText.includes("кондиционер") ||
    lowerText.includes("розетка") ||
    lowerText.includes("температура") ||
    lowerText.includes("сценарий")
  ) {
    category = "smart_home";
    confidence = 0.9;
  } else if (
    lowerText.includes("встреча") ||
    lowerText.includes("событие") ||
    lowerText.includes("календарь") ||
    lowerText.includes("расписание")
  ) {
    category = "calendar";
    confidence = 0.85;
  } else if (
    lowerText.includes("деньги") ||
    lowerText.includes("расход") ||
    lowerText.includes("доход") ||
    lowerText.includes("счёт") ||
    lowerText.includes("финанс")
  ) {
    category = "finance";
    confidence = 0.8;
  } else if (
    lowerText.includes("напомни") ||
    lowerText.includes("напоминание") ||
    lowerText.includes("напомнить")
  ) {
    category = "reminder";
    confidence = 0.85;
  }

  return {
    command: text,
    confidence,
    category,
  };
}

/**
 * Синтез речи из текста с голосом Джарвиса
 * Использует оптимальный провайдер (Yandex, Google или OpenAI)
 */
export async function synthesizeSpeech(text: string): Promise<Buffer> {
  try {
    // Используем модуль jarvis-voice для синтеза с аутентичным голосом
    const audioBuffer = await jarvisVoice.synthesizeJarvisVoice(text);
    return audioBuffer;
  } catch (error) {
    console.error("Ошибка синтеза речи Джарвиса:", error);
    throw new Error("Не удалось синтезировать речь");
  }
}

/**
 * Обработка голосовой команды
 * Распознаёт, анализирует и выполняет команду
 */
export async function processVoiceCommand(
  audioBuffer: Buffer,
  userId: string
): Promise<VoiceResponse> {
  try {
    // 1. Распознаём голос
    const recognizedText = await recognizeVoiceCommand(audioBuffer);
    console.log(`[Voice] Распознано: "${recognizedText}"`);

    // 2. Анализируем команду
    const command = analyzeCommand(recognizedText);
    console.log(`[Voice] Категория: ${command.category}, Уверенность: ${command.confidence}`);

    // 3. Формируем ответ (реальная обработка будет в routes.ts)
    return {
      success: true,
      text: recognizedText,
      action: "process_command",
    };
  } catch (error) {
    console.error("Ошибка обработки голосовой команды:", error);
    return {
      success: false,
      text: "Прошу прощения, сэр, но я не смог распознать вашу команду.",
    };
  }
}

/**
 * Проверка, содержит ли текст пробуждающее слово
 */
export function containsWakeWord(text: string): boolean {
  const wakeWords = ["джарвис", "jarvis", "hey jarvis", "привет джарвис"];
  const lowerText = text.toLowerCase();
  return wakeWords.some((word) => lowerText.includes(word));
}

/**
 * Извлечение команды без пробуждающего слова
 */
export function extractCommandWithoutWakeWord(text: string): string {
  const wakeWords = ["джарвис", "jarvis", "hey jarvis", "привет джарвис"];
  let result = text;

  for (const word of wakeWords) {
    const regex = new RegExp(`^${word}[,\\s]*`, "i");
    result = result.replace(regex, "");
  }

  return result.trim();
}


/**
 * Получает предварительно синтезированную фразу Джарвиса
 */
export async function getJarvisPhrase(
  phraseKey: keyof typeof jarvisVoice.JARVIS_PHRASES
): Promise<Buffer> {
  return jarvisVoice.getJarvisPhrase(phraseKey);
}

/**
 * Получает оптимальный провайдер синтеза речи
 */
export function getOptimalVoiceProvider(): string {
  return jarvisVoice.getOptimalProvider();
}

/**
 * Очищает кэш фраз Джарвиса
 */
export function clearJarvisVoiceCache(): void {
  jarvisVoice.clearPhraseCache();
}
